# Independent scope and feasibility review

Reviewed 11 November 2026. Read the master and seven annexes. The master now respects the latest endpoint: research, diagnosis, qualified hypothesis testing, insight and solution options, with the user selecting solutions. No critical missing workstream requires adding implementation or a final paper. The 5,000-page and 50,000-narrative values are explicitly ceilings, not guarantees; preserve that wording in the user-facing summary.

## Critical fixes before packaging

1. **Remove annex questions that reopen settled choices.** `social_methods.md`, “Clarifications that change this work,” asks whether the run must remain free/public/no-new-accounts and whether rivals/context should be included. These are already set as defaults in the master. Rephrase as execution assumptions and retain only the question of existing approved access or platform emphasis if needed. Consolidate all user questions in the master's five-question section; label annex questions internal planning notes or delete them. Do the same for the three question prompts at the end of `stakeholder_hypotheses.md` if they overlap or ask users to reselect the full 4S/case-relevant scope.

2. **Present eight-hour throughput as conditional at every summary point.** The master correctly calls the collection quantities ceilings and reserves the final quarter for synthesis. Add one explicit sentence that the actual combined 5,000 primary pages, 2,000 comparison pages, 50,000 narratives, 60 journey/device cells and 24 repeated lab cells is not a jointly promised eight-hour workload. The measured prior request latency means HTTP rate ceilings alone cannot establish achievable throughput. Calibration must allocate a smaller feasible mix, including manual QA/coding effort, rather than attempt every maximum.

3. **Do not imply host endurance can be guaranteed by inspection.** The master says to establish whether the host can sustain the window. Replace any implication of a definitive guarantee with verifying available execution controls, testing checkpoint/resume behavior and recording remaining process-lifetime uncertainty. A supported active process and persistent checkpoint do not prove an eight-hour uninterrupted run. The current honest 'no after-turn continuation' statement should remain.

4. **Keep source-record counts and source access out of outcome promises.** Social docs correctly make API access conditional. Preserve the ability to finish with a smaller, high-quality public corpus. The master should explicitly say that failure of TikTok/Instagram/X or absence of user credentials reduces platform coverage and does not trigger new account setup or an attempt to force access. This is mostly present; ensure the final user response does not list all platforms as committed collection surfaces.

5. **Distinguish validation across a sampling frame from cross-source corroboration.** The master's holdout statement permits partitioning by source family. Holding one entire platform out can test transfer, but differences in users, dates and platform selection can confound interpretation. Use independent incident/content clusters within a defined frame for primary validation where possible, and label whole-source-family holdouts as external robustness checks. Do not imply a platform-held-out pattern estimates prevalence or proves causality. The method annex already explains source selection limits; tighten this one summary sentence.

## Delivery and final response checks

- The final response should contain exactly five consolidated clarification questions and state that the large run has not begun.
- Include the earlier ZIP unchanged in the plan bundle and eventual research release, with its checksum; do not count its copied rows as new collection.
- Avoid describing the solution option catalog as a final recommendation, selected strategy or execution program.
- Include the two practical facts prominently: millions of relevant independent customer records are not promised, and hours-long active execution is conditional on runtime support and resumable checkpoints.
- Preserve that the current phase has performed planning/source capability checks only; it has not installed or tested the proposed adapters or bulk-downloaded the candidate datasets.
