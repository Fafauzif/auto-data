# Social evidence acquisition and GitHub tool assessment

Prepared 11 November 2026. Planning reconnaissance only. No adapter was installed or tested, no account was accessed, and no social corpus was collected during this review. This document distinguishes verified documentation from proposed execution. Availability is not established by a repository's feature list.

## Research objective

Recover decision episodes: intended job, offer considered, obstacle, workaround, claimed outcome and timing. Segment Digiroom software experiences, Auto2000 branch experiences, Toyota product experiences and general EV experiences. Preserve positive and contrary accounts. Specific Digiroom volume may be modest; millions of broad automotive comments would not establish millions of relevant Auto2000 experiences.

## Source and access map

| Surface | Verified route or documented tool | Prerequisite and constraint | Proposed execution priority |
|---|---|---|---|
| Google Play | `JoMingyu/google-play-scraper` exposes app and review methods with language/country parameters | Unofficial client of public store endpoints. Not an authenticated first-party Google reviews API. Needs a small runtime/terms/access validation. Pagination can end before store totals. | Highest: Digiroom, mToyota and matched automotive apps; save locale, time, app/version where present, ordering and continuation status. |
| YouTube metadata/comments | YouTube Data API official project; `commentThreads.list` returns up to 100 items per page, costs 1 unit; `comments.list` required for omitted replies | Google account, enabled Cloud project and credentials. Quota must be read from the actual project and current docs; do not assume old search quota calculations. Comments disabled/deleted are unavailable, not zero dissatisfaction. | Highest if a credential already exists and user authorizes its use; otherwise public page discovery/manual evidence, not a promised full corpus. |
| YouTube subtitles | `jdepoix/youtube-transcript-api` and `yt-dlp/yt-dlp` describe subtitle access | Caption availability varies. Automatic captions can misrecognize Indonesian car terms. Transcript API documents cloud-IP/request blocking. No proxy evasion/session import in baseline. | Bounded metadata/caption probe; retrieve text rather than video media. Record subtitle language, auto/manual and video timestamp. |
| Reddit | Approved external Reddit Data API with `praw-dev/praw` wrapper | Official FAQ explicitly distinguishes external Data API approval from Devvit login. Wrapper provides no automatic API approval or access grant. | Approved API if already available; otherwise indexed public threads as qualitative leads, with coverage gaps. |
| TikTok | Official Research Tools; unofficial `davidteather/TikTok-Api` repo also exists | Official route currently specifies regional/institutional and noncommercial eligibility, application, ethical review and approval; Indonesia-based access is not assured. The unofficial wrapper explicitly covers what is accessible logged out and does not support authenticated routes. Neither route is a guaranteed overnight collector. | Public indexed videos/captions and operator pages first; a small anonymous technical probe only after source/rules checks. Full comment coverage is optional, contingent, not a guaranteed deliverable. |
| Instagram | `instaloader/instaloader` describes profiles, captions, metadata and resumability | Maintainer issue confirms Instagram sharply restricts anonymous access; troubleshooting documents 429s and stricter cloud-IP treatment. Current functionality cannot be inferred from README. | Public indexed post examples first. Do not budget a full corpus without a successful allowed pilot. |
| Facebook/Instagram research API | Meta Content Library candidate official page | Direct documentation fetch in this review returned HTTP 429. Eligibility and terms were not verified here. Cannot claim available API access. | Deferred conditional route; not core overnight dependency. |
| X | Official X API | Current developer site describes usage-based paid credits. Public API use requires application registration. Free scraping is not assumed. | Indexed public examples only under zero-spend baseline; paid official API only if budget/access is explicitly changed. |
| Owner forums/public complaints | Ordinary accessible public HTML, individual source rules | Thread permissions, robots, relevance, duplication and source continuity differ. Account-only content omitted. | High: deeper contextual episodes, systematic source/date sampling, no assumed representativeness. |

## GitHub shortlist and adoption decisions

1. https://github.com/JoMingyu/google-play-scraper — first adapter candidate, because store reviews directly concern the app. Inspect current release/commit, license, network calls, schema and continuation behavior. Do not use unbounded `reviews_all` as the first test.
2. https://github.com/yt-dlp/yt-dlp — video metadata/subtitle candidate. Use capped metadata extraction and no media downloads. Advertised extractor coverage is not proof every platform works here.
3. https://github.com/jdepoix/youtube-transcript-api — subtitle candidate; no API key advertised, but cloud-IP blocks documented. Stop and record block rather than buy or rotate proxies.
4. https://github.com/praw-dev/praw — API wrapper candidate only when external Reddit access is already approved. No credentials or platform rights are created by installing PRAW.
5. https://github.com/davidteather/TikTok-Api — experimental anonymous candidate. Runtime/browser dependencies and live access must be tested. Not a substitute for official approval or a promise of comments at scale.
6. https://github.com/instaloader/instaloader — conditional metadata candidate; anonymous access reliability unresolved. Not a baseline commitment.
7. https://github.com/JustAnotherArchivist/snscrape — compatibility candidate, not baseline. README lists supported services including Reddit via Pushshift and X/Twitter; that does not prove those routes still function. A stale support list cannot establish overnight feasibility.
8. https://github.com/Panniantong/Agent-Reach — optional dispatch layer. Current release notes distinguish default, optional and experimental channels; release notes also remove older cookie-oriented backends. Pin the actual commit and read its current channel definition rather than copy old forks. Existing tools first; installing an aggregator does not create data rights, API approvals or free X access.

No repository code has been vendored. Stars, downloads and current documentation are not security, quality or live-access validation. Adopt a small set of adapters, with one shared evidence schema, not every tool on the shortlist.

## Proposed collection design

Search tiers: (1) exact app/company identity and spelling variants; (2) specific Toyota-owner jobs, product/powertrain and branch-locality contexts; (3) matched rival dealer/OEM jobs; (4) broad EV context retained as context, never pooled as Auto2000 customer evidence. Use Indonesian query variants including Digiroom, Auto 2000, servis, riwayat servis, booking servis, cicilan, tukar tambah, baterai hybrid, garansi, suku cadang, body repair, antre and bengkel. Search vocabulary is a seed, not the final codebook.

Proposed preapproved source-specific ceilings should be chosen by the parent plan after access calibration. Illustrative envelope: all retrievable Digiroom app reviews up to a 10,000-record ceiling, matched apps up to 5,000 each, 150–300 relevant videos with per-video comment caps, 100–200 owner/forum threads and a smaller public social lead sample. These are request budgets, not expected yields, representative samples or guaranteed source availability. Topic/channel breadth matters more than reaching the ceiling.

For every request log source, URL/ID, collector/version, requested/returned rows, time, request count, next token or terminal state and error status. Cache prior successful requests and resume pages. Unique post/comment IDs define source records. Locale mirrors, quote reposts and repeated incidents need deduplication. Replies retain thread and parent IDs, but usernames and contact details need not enter the public release.

Separate original source records, text spans, derived labels, embeddings and aggregate cells in the size report. A post with 50 coded attributes remains one post, not 50 independent customer experiences. Store app-published/update dates, review date and retrieval date separately. Engagement counters are snapshots of platform interactions; they are not sales, unique people, attitudes or outcome weights.

Sample recent and older periods, positive/neutral/negative accounts, ordinary and popular videos, time and relevance sort routes, official channels and independent owners. Exclude spam, giveaways, seller promotions, unrelated apps and pure hearsay from experience-frequency analyses while retaining them in an exclusions table. Older app builds remain a historical cohort. No historical review can prove a current defect.

## Analysis contract

Use open coding on a diverse manual calibration set, then version the codebook. Extract event sequences, actor roles, stage, claimed vehicle/branch, information mismatch, cost, trust, availability, channel workaround and claimed outcome. Distinguish first-person purchase/service accounts, prospective questions and creator opinion. A model can assist coding but cannot invent missing motivation or purchase outcome.

Evaluate topic clusters for semantic coherence, contrast automated labels with manually checked records, report reviewed counts and disagreement, and keep uncertain labels. Sarcasm, slang, negation, car-model ambiguity and mixed Indonesian/English require specific checks. Sentiment is a navigation aid; never infer root cause from a negative score.

Research tests include service-history completeness by date/version where actually present; availability-versus-findability tension; app-to-adviser workarounds; quote/invoice uncertainty; EV battery/resale concerns by HEV/BEV; software-versus-branch complaints. Differences are sample patterns until independent validation. Cross-platform prevalence and brand rankings require comparable sampling that likely will not exist.

## Stop and substitution rules

Honor source-specific limits; one shared request budget per domain across agents. Stop on confirmed challenges, persistent 429, login requirement or corrupted pagination. Do not rotate identities/proxies or import user sessions to force retrieval. Log inability, substitute an already accessible public source or reduce the claim. APIs requiring approvals are optional branches, so their absence does not strand the whole research run. Source access, rights and failure behavior are technical feasibility checks rather than a new blanket approval flow.

## Launch decisions

Use the five consolidated questions in MASTER_PLAN.md. The current defaults remain zero spend, public sources, no new accounts, and separate Auto2000, Toyota, rival and EV context cohorts. Existing approved access is optional.

## Primary sources inspected

- https://developers.google.com/youtube/data/getting-started
- https://developers.google.com/youtube/data/reference/rest/v3/commentThreads/list
- https://developers.google.com/youtube/data/reference/rest/v3/comments/list
- https://developers.reddit.com/docs/guides/faq
- https://developers.tiktok.com/products/research-api/
- https://developer.x.com/
- https://help.x.com/en/rules-and-policies/x-api
- https://github.com/JoMingyu/google-play-scraper
- https://github.com/yt-dlp/yt-dlp/blob/master/README.md
- https://github.com/jdepoix/youtube-transcript-api
- https://github.com/instaloader/instaloader
- https://github.com/instaloader/instaloader/issues/2427
- https://github.com/instaloader/instaloader/blob/master/docs/troubleshooting.rst
- https://github.com/davidteather/TikTok-Api
- https://github.com/JustAnotherArchivist/snscrape
- https://github.com/praw-dev/praw
- https://github.com/Panniantong/Agent-Reach/releases
- https://github.com/Panniantong/Agent-Reach/blob/main/agent_reach/skill/SKILL_en.md
- https://transparency.meta.com/researchtools/meta-content-library/ — unavailable (HTTP 429), not verified.
