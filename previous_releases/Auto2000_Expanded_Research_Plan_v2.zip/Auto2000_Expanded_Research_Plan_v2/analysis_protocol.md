# Expanded analysis and hypothesis-testing protocol

Status: proposed design, 11 November 2026. No collection or hypothesis test has been run for this expansion. This document extends the original evidence contract; it does not upgrade the initial reconnaissance into validated findings.

## 1. The decision and the limits of proof

The analytical objective is to understand customer decisions, ownership tasks, stakeholder tensions and commercially relevant gaps, then present broad solution options for the user to choose. This research does not select a winning strategy, design an Auto2000 implementation, or produce a rollout or commercial pilot plan. A large corpus can strengthen coverage and discover mechanisms. It cannot supply missing completed-sale outcomes, customer populations or a counterfactual merely through its size.

Use six claim states throughout: supplied case fact; directly observed public evidence; reproducible calculation; exploratory interpretation; corroborated descriptive pattern; tested effect. The last state requires an actual suitable experiment or credible comparative design. Keep modeled assumptions separate from all six. A held-out validation can confirm that a webpage pattern generalizes to a defined sample, while still leaving its customer impact unmeasured. “Prove a hypothesis” should therefore mean reject it, retain it provisionally, validate its stated descriptive scope, or identify exactly what additional observation could test its causal claim.

## 2. Separate exploration from validation

Freeze a dated initial hypothesis register before collecting the expanded sample. Entries need: task, actor, powertrain, geography, period, proposed mechanism, strongest rival, observable prediction, evidence source, exclusion rules, outcome unit, decision consequence and falsification condition. Record new ideas discovered during analysis as post-discovery hypotheses. They may be useful, but must not be presented as predictions made beforehand.

Partition independent source clusters rather than arbitrary text rows. The discovery partition is used for open coding, selecting candidate mechanisms and tuning extraction. The validation partition remains untouched until the codebook and specific prediction are frozen. Choose the partition size from actual source diversity and calibration yield, not a decorative universal ratio. Where volume permits, reserve a later time window and fresh branches/templates as a second validation challenge. Do not split near-duplicate reviews, syndicated articles, shared press releases or the same app incident across both partitions.

Many public-source findings cannot be formally tested. Mark these as triangulated working explanations, state what they explain, and retain the best contradictory account. Build a separate rejected-explanations log, including the evidence that caused rejection. “No material problem found” is a valid result for every workstream.

## 3. Sampling before NLP

Define a source-by-time-by-task coverage grid. Balance owner and shopper tasks, positive/neutral/negative accounts, EV and ICE, HEV/PHEV/BEV, national/local sources, public app versions and cities. Do not force every cell to the same size when source supply differs. Record empty, inaccessible, ambiguous and not-applicable cells explicitly.

Keep app-store, social, branch review, forum, official product and website evidence in separate sampling frames. Their users and selection processes differ. A pooled “customer dissatisfaction percentage” is invalid without a defensible sampling population and weights. Within a purposive corpus, show counts and shares only of eligible coded records, with platform and date boundaries. More scraped reviews do not eliminate self-selection or ranking bias.

The first sampled URL in every sitemap family is useful for extractor calibration, not for estimating prevalence. Replace that approach with reproducible template-stratified selection. Preserve random seeds when random selection is possible. Over-sample high-consequence tasks for diagnosis, but keep that oversampling visible.

## 4. Indonesian, mixed-language and automotive NLP

Preserve original text, capture date, content date, platform sorting, query, available app version and collection surface. Normalize a separate analysis copy: Unicode, whitespace, repeated punctuation, common abbreviations and spelling variants. Maintain a reviewed automotive alias table for model/variant names, HEV/PHEV/BEV, warranty programs and dealer branches. Keep negation, intensifiers, currency, mileage, dates and quoted speech. Do not erase slang or sarcasm before review.

Create a multi-label codebook with explicit examples and counterexamples. Proposed fields: actual task; decision stage; actor; product/powertrain; stated obstacle; information uncertainty; affordability; model fit; stock; financing; digital friction; branch response; fulfillment; data/history issue; workaround; alternative considered; reported outcome; and evidence certainty. Include “unknown,” “hearsay,” “advertisement,” “irrelevant,” “historical version” and “ambiguous actor.” An issue with branch amenities is not automatically a software defect.

Use a manually adjudicated, varied calibration set before automated coding. A suggested first review envelope is 150–300 eligible records if accessible, including short and long text, slang, negation, mixed languages, positive exceptions and competitor mentions. Adjust after class frequency is known. Keep rare high-impact mechanisms in the audit even if overall accuracy looks good. Automated labels should carry provenance and review status.

Report per-code precision/recall and disagreement examples only where a genuine held-out labeled set exists. Report inter-rater agreement only if independent annotators actually code the same items before adjudication. LLM agents are analytical reviewers, not human participants and not independent confirmation of source truth. No claimed reliability number without the underlying coding exercise. Human double coding may remain a future optional validation step.

Sentiment is a navigation tool. It should not be the central business result. Topic modeling or embeddings may identify clusters and near-duplicates; every accepted theme must return to source excerpts, event sequences and contradictory cases. Inspect cluster stability under different sample or parameter choices. Do not invent topic counts or choose a model because its chart looks distinctive.

## 5. Reconstruct customer events

The key unit for social analysis is a reported choice episode, not a sentence or keyword. Build an event table with: trigger; prior state; task; requested information; platform/branch contact; response; action/workaround; alternative chosen; reported outcome; and elapsed time if explicitly stated. Unknown chronology remains unknown. Distinguish a planned action from one the author says occurred.

Examples of useful candidate sequences include “service quote viewed → branch discount applied → invoice differs,” “history incomplete → contact adviser → record corrected,” and “compare HEV/BEV → home charging constraint → shortlist changes.” These are investigation templates, not current findings. A missing stage should not be inferred because a narrative would read better with it.

Compare positive and negative sequences for the same job. Ask what resolved uncertainty in successful cases. A complaint’s workaround can reveal the job that an existing feature fails to serve, but it may also reveal a rational preference for an adviser or a different product. Separate source-reported reasons from analyst explanations.

## 6. Dependence, duplication and a claim graph

Build an independence graph linking sources to originating incidents, shared press releases, identical product databases, copied comments, translations and syndicated articles. Hash exact copies; inspect candidate near-duplicates. Preserve a distinct relationship for “same claim” versus “same underlying event.” Do not merge people across platforms from display names. A single customer cross-posting an incident counts as one identifiable episode, while its platform visibility remains multiple occurrences.

Every accepted claim has links to supporting observations, counterevidence, contextual facts, calculations and unknowns. Source repetition is not source independence. A matched official page plus evaluator observation establishes feature representation; a review establishes one reported experience; actual operational logs would establish a fulfillment outcome. They answer different questions.

Use the graph for contradiction checks: current versus historical versions, OEM versus dealer, advertised versus observed, model year versus capture year, quoted price versus final invoice, and service due versus service captured. Resolve legitimate scope differences before calling a contradiction an error.

## 7. Candidate tests and when they are feasible

| Design | When available | What it can support | Main checks and limitation |
|---|---|---|---|
| Fresh template/branch sample | Public pages with reproducible selection | Scope of a descriptive inconsistency or missing representation | Template strata, duplicate lineage, missingness; no sales effect |
| Matched journey walkthrough | Same task and comparable location/device/account state | Differences in visible information, effort and handoff | Evaluator task, not real-user task-success rate; availability may differ |
| Public app-release interrupted series | Stable repeated outcome and known release timing | Exploratory temporal association | Public review composition and platform sorting can change; release coincides with other changes |
| Economic sensitivity diagnostic | Credible costs/margins or bounded assumptions | Which unknown commercial parameter could change an interpretation | Conditional arithmetic, not causal proof, an investment recommendation or demand forecast |

Do not retrofit a quasi-experiment merely because a release date exists. Causal claims about completed transactions would need actual outcome data and a credible counterfactual; public snapshots and reviews generally lack both. Record that evidence gap briefly. Designing or executing a future business experiment is outside this research scope.

## 8. Statistical checks that matter

Define analysis units and denominators before running comparisons. Show accessible, eligible, sampled, successfully extracted and adjudicated counts separately. Stratify by template/source/version rather than averaging incompatible populations. Review missingness by platform and task; inaccessible sources are not zero-issue sources.

For genuine probability samples, report estimation uncertainty appropriate to the sample design, using source/branch clusters where dependence requires it. A confidence interval around a convenience sample does not make it representative. For exploratory comparisons, emphasize effect magnitudes, data support and sensitivity. Avoid running hundreds of tests and selecting only favorable p-values. If a confirmatory family exists, predefine it and use an appropriate multiple-comparison approach. Otherwise label results exploratory.

Check conclusions after removing duplicate incidents, dominant source families, historical versions, low-confidence coding and the most visible platform. Recalculate after alternative entity joins and legitimate price-scope reconciliations. A finding that disappears when one source is removed should be reported as fragile. Never use fabricated conversion labels to train or validate a model.

## 9. Turn tensions into distinctive insights

Build an insight lab around competing mechanisms rather than a generic SWOT. Potential tensions to investigate include:

- Quiet app periods may be rational ownership cadence, while rare battery or trade-in events have high transaction value.
- A customer may want self-service information yet prefer assisted commitment because a branch must confirm an exception.
- Locally personalized adviser pages may improve lead routing while creating central price/specification maintenance problems.
- A service-history feature can exist while its completeness, latency or interpretability remains inadequate for a specific decision.
- More digital bookings can fill idle bays, displace better work in full bays, or simply move an unchanged transaction between channels.
- Vehicle education may already exist on an OEM property; the unmet need may concern context, trust or continuity rather than new content.
- A household's user, payer and driver may differ; a fleet's administrator and driver may need different interfaces.

These are candidate mechanisms, not accepted findings. Accept an insight only when it identifies an actor, condition, trade-off and management decision; cites source lineage and contrary evidence; and explains what remains unquantified. Do not force a prescribed number of “surprising” insights or numerical novelty scores.

## 10. Broad solution options for user selection

Develop materially different broad options after evidence review. Proposed option families are: decision support using existing OEM/partner information; clearer digital-to-branch request and confirmation communication; ownership record and battery-condition continuity; task-specific local discovery and capability information; commercial information or financing integration concepts; and simpler information/content corrections. Include the current approach as a comparison and note where a partner already provides a relevant capability. These are idea families for the user to consider, not recommendations to build them.

For every option card write: evidence-linked insight; affected segment; broad concept; proposed mechanism; existing capability check; potential distinctiveness; stakeholder benefits and burdens; dependencies; commercial trade-offs; strongest counterevidence; and unresolved assumptions. Keep costs indicative only where defensible sources exist. Do not add delivery assignments, build specifications, work packages, timelines, rollout phases, commercial pilot designs or a final preferred strategy. The user chooses which possible solutions to develop.

## 11. Economic interpretation without implementation planning

Construct cohort economics by powertrain, vehicle age, mileage/service-entitlement state, task and location where evidence permits. Potential incremental vehicle GP equals eligible opportunities × incremental fulfilled-purchase probability × realized GP per delivery, adjusted for substitution and discounting. Potential after-sales GP equals installed vehicles × jobs due × incremental capture probability × GP per job, adjusted for displaced jobs and partner share. Cost savings require economically realizable staff/capacity effects, not simply minutes multiplied by average salary.

Use sourced actuals where available and bounded assumptions elsewhere. Keep casebook averages at their stated business-line scope. Explain the difference between gross profit, recurring operating contribution and investment. The case's Rp150 billion 2026–2028 cap remains context for later user decisions, not a reason to design an investment program here. If useful, show a small sensitivity or break-even relationship to explain commercial materiality, with every unknown labeled. Do not present an ROI forecast, capital allocation or funded implementation plan.

Compare broad options through transparent trade-offs rather than unexplained weighted scores or an overall winner. Show which conditions would make each concept more or less attractive. Flag unknowns that could reverse its apparent appeal. A larger dataset is useful only if it reduces that uncertainty or exposes a materially different customer or stakeholder perspective.

## 12. Required analysis outputs and review roles

Deliver a versioned hypothesis register; codebook and labeled calibration/validation extracts; source-independence map; event-sequence table; descriptive coverage and contradiction atlas; accepted/rejected/unresolved insight ledger; insight cards; broad solution option cards; and a concise evidence-gaps register. Include economic diagnostic relationships only where they clarify the insights. The executive report should contain defensible findings while the evidence companion retains wider discovery. No Auto2000 implementation, rollout, commercial pilot or final winning-strategy deliverable is included.

Allocate separate agents to exploration, counterevidence, coding QA, economics and skeptical stakeholder review. Give each a bounded source/task remit and require evidence IDs. The synthesis owner reconciles their claims. Agents should not independently repeat the same crawl or count agreement between their summaries as corroboration. A skeptical reviewer receives the proposed conclusion, its strongest evidence and explicit instructions to find the conditions under which it fails.

Release only claims whose cited observations exist and whose calculations reproduce. The final limitations table should identify the specific missing evidence behind each unresolved question, without expanding into a future implementation or experimentation program.
