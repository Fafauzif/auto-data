# Auto2000 Digiroom expanded research plan

Version 2 prepared 11 November 2026 Asia Jakarta
Status Planning review only awaiting clarification before the large run

## Purpose and scope

This engagement will produce a deep understanding of Auto2000 and Digiroom, test competing explanations for the case problem, discover distinctive business insights and present a broad menu of possible solutions for the user to choose. It covers the company, market, customers, stakeholders, public digital experience, competitive mechanisms and economic consequences. It stops before final strategy selection, Auto2000 implementation planning, product building, rollout design or competition submission production. Research automation and analysis code are necessary means of producing the evidence, not a product implementation project.

The decision question is where Auto2000 could create or protect profitable value for electrified vehicle buyers and owners through its digital and dealer ecosystem. The inquiry must allow the answer that low app use is rational, that another channel serves the customer well, that product and affordability dominate digital friction, or that a seemingly exciting problem has little commercial importance. It must also identify capabilities and customer experiences that already work.

The full 4S model remains in scope: vehicle sales, service, spare parts, and body and paint. Separate HEV, PHEV, BEV and conventional vehicles; new buyers, existing owners, replacement buyers and fleets; Toyota brand share, Auto2000 dealer capture, channel attribution and incremental profit. The case's Rp150 billion investment envelope for 2026 to 2028 informs option feasibility only. No portfolio or investment allocation will be selected on the user's behalf.

## What changes from the earlier release

The earlier archive contains reconnaissance, not a completed pilot. Its records include 8,436 valid sitemap declarations across 27 sitemap files, corresponding to 7,687 unique URLs, and 20 raw HTML fetches covering 19 requested URLs. None is a visitor, sale or verified customer. Its market and qualitative notes provide leads that require freshness and provenance checks.

The next run adds systematic social evidence, reusable public datasets, source and entity reconciliation, stakeholder incentive analysis, a larger matched competitor program, hypothesis discovery and independent validation, Indonesian text analysis, commercial mechanisms and a structured solution catalog. We will retain the old archive byte for byte under previous_releases and track which old observations were rechecked, superseded or left unresolved. Copying the old data does not add new evidence.

## Research structure

| Workstream | Main decision question | Main output |
|---|---|---|
| Business and case fact base | What value is at stake and actually within the dealer's control | Reconciled definitions, 4S value drivers and discrepancy register |
| Market and commercial offers | Where do model fit, price, credit, warranty and ownership economics shape choices | Market panel and comparable offer database |
| Customer roles and choices | Who searches, influences, pays, owns, drives and resolves problems | Decision episodes and lifecycle maps grounded in evidence |
| Social and app evidence | What do people report doing, encountering and choosing instead | Deduplicated narratives with context, contrary cases and selection limits |
| Digital jobs and discovery | Can a person find an offer, evaluate it and reach a credible next step | Matched journey records and job to capability map |
| Content and information consistency | Are published answers useful and consistent for the correct vehicle and locality | Fact graph, content families and evidence gaps |
| Local service geography | Where do published dealer capabilities and charging conditions differ | Branch and charging coverage comparisons with geographic limits |
| Competitors and adjacent ecosystems | Which mechanisms address equivalent jobs and what are their tradeoffs | Matched mechanism library including Auto2000 strengths |
| Stakeholder economics | What incentives and dependencies could explain observed behavior | Stakeholder map and commercial mechanism hypotheses |
| Evidence synthesis | Which explanations survive disconfirmation and which remain uncertain | Hypothesis ledger, diagnostic findings and insight cards |
| Solution exploration | What materially different responses follow from the findings | Broad solution menu with evidence, tradeoffs and rough economics |
| Independent review and delivery | Can another reviewer reproduce and challenge the argument | Source register, claim audit, counterarguments and reusable archive |

The supplied BCC guide informs the sequence: frame the case, decompose the question, derive research questions, investigate business/market/customers, synthesize and then generate solutions. Its implementation chapter does not expand this assignment. Frameworks are used only where they answer a question; the report will lead with insights and their implications rather than a stack of generic analyses. Detailed guide alignment appears in the annex.

## Source acquisition and GitHub tools

Core candidates are the Auto2000 public site, public app-store listings and reviews, Toyota and partner documentation, accessible owner forums, publicly available video metadata and captions, industry market files, government aggregates, published research and matched competitor pages. Each candidate must pass a live small-sample check before scale. Official descriptions establish advertised capabilities; evaluator walkthroughs establish observed interface states; neither establishes fulfilled transactions.

The strongest initial GitHub candidates are JoMingyu/google-play-scraper for bounded Play review pagination, jdepoix/youtube-transcript-api or yt-dlp for available captions/metadata, and a single Scrapy or Crawlee collection queue. Playwright supports selected interactive walkthroughs. DuckDB with Parquet or SQLite supports analysis when useful. PRAW, TikTok-Api, Instaloader, snscrape and Agent Reach remain conditional adapters, not assumed access. Pin versions, inspect outbound requests and licenses, then run a small probe. No tool has been installed for this enlarged study during planning.

YouTube's official comments route requires an enabled project and credentials. TikTok Research Tools require eligible location/organization and approved access; an Indonesian business-case study cannot assume eligibility. Reddit requires approval for its API. Anonymous Instagram access is unreliable according to maintainer reports. A repository's feature list does not prove current platform access. These routes have documented alternatives and can fail independently without stranding the whole study. No new accounts, paid tools or session imports are assumed under the existing preferences.

Social discovery uses four separated relevance tiers: direct Digiroom/Auto2000; Toyota owner and buyer episodes; matched rivals; broader Indonesian EV context. Search spelling variants and job-specific terms such as riwayat servis, cicilan, tukar tambah, garansi baterai, antre bengkel and booking servis. Include ordinary and highly engaged items, positive and negative experiences, earlier and recent periods, official channels and independent owners. Label prospective questions, firsthand accounts, hearsay, seller promotions and creator opinions separately. Do not treat view counts, likes or sampled complaint shares as demand or prevalence.

For app reviews, retain source review ID, locale, sorting, date, available app version, rating, developer-reply status and pagination completeness. For video narratives retain video/thread IDs, transcript timestamp, language and whether captions are automatic. Preserve parent-child relationships in discussions. Remove unnecessary personal identifiers from the release. Reposted text, locale mirrors and repeated incidents must not masquerade as independent confirmations.

## Reusable datasets and enrichment

The dataset catalog identifies nine source families, including GAIKINDO market tables; BPS vehicle stock and household expenditure aggregates; official Jakarta charging metadata; Geofabrik OpenStreetMap extracts; Open Charge Map; IndoNLU CASA automotive sentiment data; IGAR Indonesian app-review data; and GDELT news metadata. Access, file schemas, dates and licenses must be validated before adoption. Catalog availability is not proof a downloadable usable table exists.

Use market tables to distinguish segment growth from within-segment performance. Use vehicle stock to avoid substituting new sales for the installed fleet. Use local charging and dealer data for bounded geographic comparisons, not claims of live uptime or national completeness. Treat household expenditure as aggregate affordability context, not the income of Auto2000 visitors.

IndoNLU and IGAR are auxiliary language resources. They may help evaluate an Indonesian aspect or event classifier, but their records are not current Auto2000 customers. Millions of OpenStreetMap primitives are geographic support data, not millions of dealership insights. Keep all auxiliary rows and objects in a separate count and analysis partition. Do not download a large corpus merely because its size looks impressive. Check exact subset licenses before distributing any dataset; code licenses do not automatically license all source data.

## Scale and runtime envelope

The recommended design is an eight-hour active research envelope, subject to the user's choice and host capabilities. This is a proposed maximum, not a promised completion time or an active overnight process. Six specialist agents can work beside the lead, with roles rotated in waves; one central collector governs source traffic across all agents. Parallel analytical work does not justify parallel uncontrolled scraping of the same domain.

A first 30 to 60 minute calibration batch measures access, throughput, extraction quality, coding effort and storage. It does not impose another user approval checkpoint within an agreed scope. Replace failed source routes, reduce low-value fields and continue on viable branches. Reserve approximately the final quarter of the chosen active budget for cleaning, synthesis, challenge and packaging, rather than exhausting time on collection.

| Collection family | Proposed eight hour ceiling | Counting rule |
|---|---|---|
| Auto2000 pages | Up to 5,000 relevant distinct pages from refreshed inventory | Separate declarations, fetched URLs and unique content families |
| Competitor and partner pages | Up to 2,000 pages across an explicitly named domain set | Separate OEM, dealer and adjacent platform mandates |
| Direct and contextual narratives | Up to 50,000 relevant retrievable records across approved sources | Split direct Auto2000, Toyota, rivals and EV context; deduplicate |
| Videos with metadata or text | Up to 300 relevant videos where accessible | Count videos separately from transcript segments and comments |
| Owner discussion threads | Up to 200 relevant public threads | One thread may contain multiple posts and repeated incidents |
| Safe journey scenarios | Up to 60 scenario and device cells | Record completed, partial and inaccessible cells separately |
| Search query and context cells | Up to 400 recorded cells | Search ordering is not an independently measured Google rank |
| Local geography | Up to 12 Indonesian markets with four deeper city comparisons | Published capabilities and dataset coverage only |
| Market and offer records | Up to 500 comparable model variant locality offer observations | Preserve validity date, terms and powertrain definitions |
| Controlled lab cells | Up to 24 page device contexts with up to three repetitions | Lab measures are not field user experience |

These are ceilings, not expected yields or minimum quotas. The maxima are not a jointly promised eight hour workload; calibration will select a feasible mix and preserve analysis time. In a zero-key public-source run, the social corpus may be much smaller. The calibration should reprioritize by marginal decision value. An exact-app corpus may contain far fewer retrievable records than the store's displayed rating total. Subrequests, retries, browser resources and external dataset downloads have separate counters. A provisional 20,000-request and 5 GB scratch cap must be adjusted to actual host headroom before starting; it does not authorize careless refetching or third-party overload.

A million useful structured values may arise from several thousand pages, links and coded text segments. We will report original documents, unique narratives, people if actually identifiable without inference, attributes, links, segments, repeated tests and auxiliary objects separately. There is no promise of a million independent relevant customer records and no aggregation that disguises this distinction.

Sleeping does not require the user to supervise intermediate batches. While a supported active run continues, agents work and checkpoint automatically. Before launch, inspect available execution controls, test checkpoint and resume behavior, and record remaining process lifetime uncertainty. Host inspection cannot guarantee uninterrupted endurance. No claim will be made that a process persists after the assistant turn ends. If interrupted, the next session resumes from durable queues and packaged checkpoints; an external runner is an optional separate decision, not an assumed setup burden.

## Stakeholder perspectives and hypothesis program

The annex maps 17 stakeholder perspectives and 25 initial hypotheses. These include customers and family influencers, fleet administrators, advisers and branch heads, workshop staff, digital leadership, finance, CRM/privacy, OEM and partners. Treat their objectives and incentive conflicts as hypotheses unless evidenced by the case or public documentation. An agent role-playing a CFO is an analytical lens, not a CFO interview.

Illustrative tests include low usage caused by natural job cadence versus usability; WhatsApp as a valuable exception-resolution route versus forced workaround; battery uncertainty affecting the purchase versus upfront affordability; lower workshop visits from fewer jobs due versus dealer defection; ownership-record gaps versus normal completion delay or version differences; generic content versus valuable adviser localization; and new feature gaps versus weak connection of capabilities already present.

Each hypothesis specifies the affected task/cohort, proposed mechanism, rival explanation, evidence that would change the conclusion, obtainable sources and the decision it affects. New hypotheses discovered during exploration are dated as such. Primary validation holds out independent incident or content clusters within a defined sampling frame rather than splitting near-duplicate sentences. Holding out an entire source family is an external robustness check, with platform population and timing differences recorded as potential confounders. An explanation is not marked supported simply because three agents agree or several pages repeat one press release.

We can verify specific observable facts, corroborate or weaken patterns, reject contradicted hypotheses and identify unresolved mechanisms. We cannot prove causal sales or profit uplift from scraped comments alone. Where internal transaction data or real experiments would be required, document the missing evidence without constructing a fake experiment or an implementation program.

## Analysis and distinctive insight development

First reconcile entities, time, powertrain, offers, branch identities and provenance. Preserve original values beside parsed fields. Distinguish absent from inaccessible, extraction error and not collected. Audit a diverse extraction sample, all high-consequence anomalies and the codebook's ambiguous categories. Shared navigation and syndicated advice should be identifiable so they do not dominate results.

For Indonesian and mixed-language text, begin with manual open coding and an explicit glossary. Then use reproducible retrieval, clustering or aspect/event classification to organize the corpus. Evaluate automated coding on unseen manually reviewed cases and report actual disagreement, unknown labels and examples. Benchmarks may assess NLP performance; they do not validate current customer behavior. Do not force a sentiment percentage where source sampling cannot support it.

High-value analyses include customer event sequences and channel workarounds; known capability versus findability; model-year and locality price consistency; owner-job versus acquisition-job coverage; dealer capability versus represented promise; OEM/dealer/partner responsibility; warranty-stage ownership needs; financing cash-flow tradeoffs; battery/resale uncertainty by powertrain; and geographic service/charging context. Apply methods only when data supports the relevant unit and comparison.

Each accepted insight must explain what was observed, why it may happen, who is affected, what makes the result specific to Auto2000, its strongest counterexample, its business consequence and which choices it opens. Use a small decision-relevant synthesis while preserving the wider discovery library. Plausible strategic tension is more useful than a generic statement that customers value convenience.

## Solution menu for the user to choose

Generate approximately 20 to 30 genuinely distinct candidate concepts across six to eight families if evidence yields that many useful responses. Consolidate duplicates and retain fewer substantive choices rather than invent variants to fill a quota. Every item is labeled as evidence-linked, conditional or exploratory. Include both new ideas and simpler ways to improve or connect existing capabilities.

Possible families to explore, not preselected recommendations, include assisted purchase confidence; affordability and finance navigation; ownership records and service clarity; battery health and resale confidence; local branch/service discovery; fleet and multi-vehicle tasks; partner integration and role clarity; and the information/data consistency behind customer decisions. Include Auto2000's strengths and an option to retain an already effective approach where appropriate.

Every solution card will state the customer job and segment, evidence and claim IDs, the proposed mechanism, a concrete customer-use example, existing comparable features, differentiation and transfer limits, who benefits and who bears a cost, important dependencies, rough value/cost logic where defensible, tradeoffs, failure conditions and evidence still missing. These are decision cards, not rollout schedules, detailed technical specifications or implementation plans.

Compare options on evidential support, relevance, customer value, commercial logic, novelty in the specific ecosystem, dependency burden and uncertainty. Do not choose a winner or hide judgment inside an arbitrary total score. Highlight which options solve different problems, which could coexist, and which assumptions would change their attractiveness. The user decides what to pursue.

## Parallel work and independent challenge

Wave one uses six specialists on commercial/market, customer/social, journeys/content, datasets/geography, stakeholders/partners, and methods/data engineering. Wave two reallocates capacity to coded evidence, source contradictions, matched benchmarks, hypothesis tests, economic mechanisms and solution diversity. The lead reconciles units and sources across streams. Each collector uses the shared scheduler; specialist agents mostly analyze cached and attributable evidence.

Before accepting a diagnosis, a reviewer who did not originate it seeks a competing explanation. Before adding an option, another reviewer checks whether it already exists, whether Auto2000 could control the promise and whether the cited evidence supports the exact problem. Final challenge rotates buyer, adviser, workshop, CFO, privacy/OEM and skeptical judge perspectives. Agent agreement is never counted as source independence. Reuse completed agents rather than spawning duplicates indefinitely.

## Outputs and acceptance

The final deliverable is a portable research ZIP with an executive reading guide; full research report; customer and stakeholder maps; source and dataset catalog; hypothesis ledger; insight cards; broad solution menu and comparison; transparent economic driver tables where supported; reproducible code and schemas; structured evidence data; quality/exclusion logs; counters and resume instructions; and the exact prior release as a nested archive.

The executive reading guide will lead with supported findings and open choices. The long report preserves useful discoveries beyond the eventual IBSC argument. The solution menu leaves final selection to the user. A competition paper, slide deck, product prototype, detailed business implementation roadmap and operational pilot are outside this assignment unless requested later. The casebook's submission format and rubric remain reference context only.

Accept the release when every material claim links to original evidence or clearly labeled assumptions, calculations retain inputs, duplicates/missingness are visible, all negative/contrary evidence survives synthesis, data units are honestly counted, high-impact claims pass independent review and the archive opens correctly. If a branch is unavailable, state the resulting limit and adjust the conclusion rather than replacing it with fabricated certainty.

The current plan bundle includes the unchanged original research release. The later research ZIP will include it again. Save checkpoints before expensive work and final synthesis. Retry the requested Filebin backup at release time, verify the response and checksum if uploaded, and record any returned expiry. A previous attempt failed with HTTP 507, so Filebin is an optional second copy rather than the sole deliverable. No new upload is needed merely to approve this plan.

## Clarifications before launch

1. Choose the active research ceiling: four hours, eight hours recommended, or twelve hours. The host capability check may require resumable batches; no unsupported overnight guarantee.
2. Choose executive report language: English recommended for the current conversation, Indonesian, or English with an Indonesian summary. Original Indonesian evidence stays in its source language where useful.
3. Should solution cards include rough economics and feasibility comparisons, or remain concept and evidence focused? Recommended: rough comparisons where inputs support them, without implementation planning.
4. Do you already have usable research inputs beyond public sources, such as existing approved YouTube/Reddit API access, sanitized customer notes or internal aggregate data? None is required, and no new accounts or paid services are assumed. Do not paste credentials into chat.
5. Name any competitors, customer groups, cities or hypotheses you particularly want challenged. Default is a balanced national lens, deeper matched dealer/OEM comparisons and clearly separated direct Auto2000 evidence and wider EV context.

Planning source notes and technical details are in the six specialist annexes plus the BCC alignment file. They are proposals and capability checks, not outputs of the future large research run.
