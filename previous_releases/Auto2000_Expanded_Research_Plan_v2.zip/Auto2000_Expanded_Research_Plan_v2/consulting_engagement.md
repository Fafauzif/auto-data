# Auto2000 / Digiroom: comprehensive research and diagnosis engagement

Status: proposed research scope, not an executed study. Prepared 11 November 2026. Latest user instruction controls the endpoint: comprehensive research, diagnosis, qualified hypothesis testing, distinctive insights and a broad solution option menu. The user will choose the solutions. Final selection, implementation design, rollout/pilot roadmaps, product build and a final competition paper are outside the present assignment unless later requested.

## Engagement question and research endpoint

Where does Auto2000 create, lose or leave unrealized value across acquisition, ownership and replacement in an electrifying Indonesian vehicle market; what evidence explains those patterns; and what materially different responses could address them?

The study must preserve the case's business context: 4S revenue and gross profit, HEV/PHEV/BEV differences, digital technology as a strategic lever, customer data concerns and the Rp150 billion incremental investment cap for 2026–2028. These constraints inform analysis and option trade-offs; they do not authorize choosing or implementing a solution. Public evidence can reveal capabilities, inconsistencies and candidate mechanisms. It cannot recover private funnels, branch performance, actual EV-specific margins or causal effects without suitable data.

The work follows the supplied *Cracking Case Competitions Guidebook – Indonesian*, particularly printed pp. 23–39 on problem understanding and pp. 41, 44–50 on broad option generation and feasibility logic. It does not adopt the guidebook's later selection or implementation steps where these conflict with the user's requested boundary. See `bcc_guide_alignment.md`.

## Workstreams and research deliverables

| Workstream | Questions and analytical work | Tangible deliverable | How it helps the user's later decision |
|---|---|---|---|
| Business fact base | Reconcile definitions, wholesale/retail/dealer reach, HEV/PHEV/BEV, installed base, 4S economics, entitlements and budget treatment. | Reconciled fact book, economic-driver map and uncertainty register. | Establish what opportunity is actually within Auto2000's reach. |
| Market and competitive position | Compare actual offers, affordability, availability representations, warranty, financing, resale, ownership propositions and channel capabilities. Distinguish OEM from dealer mandates. | Market map, matched offer/job benchmarks and competitor mechanism library. | Show whether product/price fit or channel experience better explains a gap. |
| Customer decisions and evidence | Trace who searches, influences, pays, owns, drives and fulfills; code public narratives by event, uncertainty, alternatives, workaround and reported outcome. | Role-based decision maps, lifecycle journeys and customer evidence atlas. | Explain customer trade-offs without assuming public reviewers represent all owners. |
| Digital experience and discovery | Inspect public website/app routes, content, accessibility, information architecture, technical discoverability and handoffs. Compare equivalent jobs. | Job-to-capability map, observed journey evidence, consistency graph and bounded issue inventory. | Distinguish capability absence, poor findability, unclear information and untested fulfillment. |
| Stakeholders and operating constraints | Examine incentives, Single ID representations, lead assignment, adviser work, appointment representations, partner control and capacity constraints. | Stakeholder incentive map, current-process hypotheses, dependencies and unresolved operational questions. | Reveal whose interests or capabilities may support or constrain each option. No future operating model is designed. |
| Hypothesis generation and challenge | Build rival explanations, seek contrary cases, separate observed associations from causal effects, and identify conditions under which a preferred explanation fails. | Hypothesis register with supported, weakened, contradicted or unresolved status and a claim-to-evidence trail. | Reduce overconfidence and expose which explanation changes the business interpretation. |
| Diagnosis and insight synthesis | Combine business, market and customer evidence into specific, decision-relevant patterns. Distinguish independent corroboration from shared source lineage. | Diagnosis report, insight book, contradictions log and material evidence gaps. | Give the user a defensible account of what seems to matter and why. |
| Broad solution option exploration | Generate alternatives from commercial, operational, digital, information, integration and partnership perspectives. Use comparable mechanisms and explicit transfer limits. | Broad option menu and evidence-backed option cards, retaining alternatives rather than selecting a winner. | Give the user distinct choices with customer value, assumptions, trade-offs and reasons each might fail. |
| Economic implications and limits | Map revenue/GP mechanisms and conditional break-even requirements; account for channel migration, cannibalization, discounts, service entitlement and capacity. | Economic-driver tables, assumption register and conditional sensitivity analysis where inputs support it. | Show what must be true for an option to matter. No fabricated ROI or selected investment allocation. |
| Decision support and research handoff | Organize findings and methods so the user can inspect evidence and compare options independently. | Executive research synthesis, full report, datasets, methods/code, option matrix and question-and-answer evidence pack. | Equip the user to choose solutions later. A final competition paper or presentation is not produced now. |

## Option cards and comparison boundary

Each option card should contain: the specific problem and affected actor/job; supporting evidence and counterevidence; the proposed mechanism at concept level; existing analogous capabilities and their differences; customer and stakeholder trade-offs; major capability/partner/data dependencies; economic drivers; uncertainty; and circumstances where the option would be inappropriate.

Options may include a simple baseline improvement and a more extensive alternative. Compare using factual dimensions and transparent ranges, such as reachable customers, control/dependencies, likely customer value, cost categories and sensitivity. Do not use an unsupported weighted score or select a winner. Identify options weakened by evidence and explain why; preserve the remaining menu for the user. Concept-level mechanism and feasibility context are allowed, while detailed future workflows, builds, roadmap phases, pilot design and deployment choices are deferred.

## Hypothesis-to-option example, explicitly unproven

Possible observation: public descriptions advertise service booking while some public narratives discuss uncertainty about service records or invoice detail. Candidate explanation A is data continuity; rival B is normal lag between provisional and completed jobs; rival C is version/account-specific behavior; rival D is a branch issue unrelated to Digiroom. Evidence should discriminate these explanations where possible. If a material gap is corroborated, possible responses might include clearer record-status information, data continuity improvements, an assisted confirmation service or no intervention if the apparent gap is obsolete. These are alternatives for comparison, not recommendations selected in advance.

## Evidence maturity

Use statuses: supplied case fact; directly observed public evidence; derived calculation; exploratory explanation; corroborated pattern; contradicted explanation; modeled assumption; unresolved. Reserve tested causal effect for a suitable experimental or credible comparative design actually supported by data. A larger scrape can strengthen pattern coverage; it cannot transform observational public text into proof of causality. A precise, decision-relevant economic implication can be valuable even if it is not surprising.

## Research report argument

1. The research question, scope and what the evidence can answer.
2. Business and market fact base, including reconciled definitions and contradictions.
3. Customer roles, jobs, alternatives and reported choice sequences.
4. Current capabilities and observed digital/local/partner handoffs.
5. Hypotheses, strongest rivals and outcomes of available tests.
6. Supported patterns, distinctive insights and unresolved questions.
7. Broad solution option menu with evidence, analogues, dependencies and trade-offs.
8. Economic drivers and conditional implications, with assumption sensitivity.
9. Research limitations and the remaining information that could change the user's choice.

Keep raw technical inventories and source-specific exhibits in companion files rather than letting collection volume bury the diagnosis. The casebook's eventual paper rules remain reference context, not a current production requirement.

## Unsettled clarification questions before the full run

Do not reopen the full research scope, no-paid-tools baseline, prior ZIP inclusion or the user's right to choose solutions. Ask only questions that change execution or output:

1. What active-run ceiling should the later session use: 4–6 hours, 8–12 hours if supported, or several resumable sessions? The host's actual lifetime and persistence must be verified; no after-turn continuation is assumed.
2. Should the report and option cards be in English, Indonesian or English with Indonesian executive summaries?
3. Which geographic depth is most useful: a balanced national sample, a Java-heavy urban sample, or named cities relevant to the user? National market context can remain regardless.
4. Which comparison group deserves the deepest coverage: Indonesian dealer competitors, EV OEM/customer ecosystems, or both equally? Adjacent finance/trade-in platforms can serve as mechanism benchmarks.
5. Is there an actual decision/submission deadline or latest evidence cutoff that should bound collection and synthesis?

If the user leaves an optional preference unanswered, record a reasonable default and proceed only after the requested pre-run review has concluded. Do not turn ordinary analytical choices inside an approved envelope into repeated permission requests.

## Prior release preservation

Include the unchanged `Auto2000_Public_Research_Initial_2026.zip` in the later deliverable with checksum and a reconnaissance label. Do not double-count the old sitemap rows, copied source links or repeated observations as new evidence. Include a migration note showing which old findings were rechecked, corrected or superseded.
