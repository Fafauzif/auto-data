# Auto2000 public research: initial collection and resumable inventory

Research date: 11 November 2026. This is an initial research release, not the completed large-scale study specified in the plan. No claim of millions of observations is made. See results/sitemap_run.json for actual counts and access failures. Sitemap entries are declared URLs, not verified pages, customers, searches or transactions. Numbers may include duplicates; lastmod is site-supplied and is not proof of update.

## Included
- `results/market_notes.md`: market sources, discrepancies and economics.
- `results/journey_notes.md`: eight public-source journey and benchmark observations.
- `results/customer_notes.md`: small nonrepresentative customer-voice sample and historical study.
- `results/seo_notes.md`: targeted content and local-discovery observations. A later sitemap inventory adds coverage but does not establish page indexing or traffic.
- `results/sitemap_urls.csv` and `results/sitemap_run.json`: actual declared URL inventory and crawl log. Files may be partial.
- `scripts/sitemap_inventory.py`: inventory method. It requires an index file at `/tmp/auto_sitemap`, retrieved from https://auto2000.co.id/sitemap.xml, checks valid same-domain URLs, pauses between requests and stops on request failure. Running again replaces the inventory; it is not a resume-capable collector.
- `Auto2000_Research_Plan/`: original research framework and instruments. Its permissions describe the earlier planning state, not the user's subsequent explicit instruction to run the research.

## Important limitations
This is a targeted source review and sitemap inventory. It is not a balanced pilot, mobile app test, 12 journey walkthroughs, full competitor audit, representative customer study, performance benchmark, live-site conversion analysis, causality study or final IBSC solution. Historical complaints are not evidence of current prevalence. Search-retrieved pages may be cached. Public site descriptions show intended features, not actual customer outcomes. Casebook metrics are case assumptions; incompatible figures require reconciliation. No user private casebook or reviewer identifiers are included.

## What the evidence suggests investigating
1. Digiroom and mToyota advertise overlapping jobs; investigate role clarity and integration before building features already offered. Actual overlap in customer use is unknown.
2. Historical service-history concerns and positive reviews coexist. Check record completeness and timing on current versions before asserting a problem.
3. One hybrid maintenance article lacks a worked numerical example in retrieved text. Test whether targeted comparisons help customers, alongside price and product fit.
4. Service profitability must distinguish work due, capture share and profit per completed job. Case line margins are not EV-specific.
5. National sales mix is not the installed fleet. Toyota HEV and BEV maintenance needs differ.

## Next work
Complete the pilot sampling and live evaluator walkthroughs with recorded viewport and page states, compare matched competitors, audit a balanced sample and validate data extraction; then evaluate meaningful expansion. Internal funnel, branch, customer and cost data are required to validate business impact. Filebin is a public third-party share; do not add private documents or credentials. Source content and trademarks remain subject to their respective rights.

## Actual run counts
The full sitemap index named 27 children. All 27 were retrieved and parsed successfully on this run. They declared 8,436 valid same-domain URL entries, corresponding to 7,687 unique URLs. The inventory is a site declaration, not a verification of those URLs' status, indexing, content, or commercial importance. Rows are not independent customer or transaction observations.

A convenience sample fetched 20 raw-HTML responses across sitemap families, representing 19 distinct requested URLs because two families selected the same URL. All 20 curl fetches succeeded. Titles and descriptions appeared in all 20; 11 responses lacked a canonical link in the initial HTML. This is not a representative prevalence rate, rendered-page result, indexing failure, or search penalty. The sample was selected as the first eligible URL per family, not randomly. Redirect final URLs were not recorded; no desktop/mobile rendering, performance or participant usability tests were completed. See `results/page_sample.json` and `scripts/page_sample.py`. The site's robots rules were reviewed; no login, form submissions, or private account use occurred. The crawler does not extract URL headers or preserve screenshots.
