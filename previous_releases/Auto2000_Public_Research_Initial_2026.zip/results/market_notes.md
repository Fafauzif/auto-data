# Auto2000 market and economics research notes
Accessed 11 November 2026. Scope: targeted public-source research, not a complete market study. Casebook values are competition assumptions and do not represent audited Auto2000 financials.

## Evidence and implications

1. **Different electric-vehicle definitions change the apparent market size.** The supplied case reports Indonesia's 2025 electrified wholesale market as 175,144 units and 21.8% of total wholesales; it includes HEV, PHEV and BEV (casebook p. 8). The [IEA Global EV Outlook 2026](https://www.iea.org/reports/global-ev-outlook-2026/trends-in-electric-cars) estimates electric cars at 15% of Indonesian new-car sales in 2025 and notes BEV imports from China and incentives. Its category differs; figures are not directly comparable. IEA reports broadly describe BEVs and plug-in hybrids, not conventional HEVs. Don't present the discrepancy as a correction without reconciling definitions and basis.

2. **Hybrid leadership is clear, the exact share varies by source definition.** The [GAIKINDO-hosted report](https://www.gaikindo.or.id/innova-zenix-pimpin-penjualan-mobil-hybrid-nasional-tahun-2025/), republishing Detik using GAIKINDO data, gives 65,943 hybrid wholesales and 30,110 Toyota hybrid units in 2025. The resulting 45.7% is a calculation, versus the casebook's 51%. Denominator and model classifications require reconciliation. It is a reported secondary analysis hosted by the industry association, not a verified independent primary table. Toyota Innova Zenix hybrid accounted for 23,934 units in the report, showing model concentration.

3. **A dealer-share assumption needs scrutiny.** [Auto2000's own 2025 results](https://auto2000.co.id/berita-dan-tips/auto2000-optimis-sambut-2026-berkat-layanan-yang-dekat-nyaman-dan-lengkap) report approximately 106,000 vehicles sold and 2 million after-sales unit entries. [GAIKINDO](https://www.gaikindo.or.id/indonesias-vehicle-retail-sales-january-december-2025/) reports Toyota's national 2025 retail sales of 258,923. Approximate ratio 106,000 / 258,923 = 40.9%. These sources don't verify identical definitions, geography or channels, so the ratio is a reconciliation flag, not a replacement for the case's 70–80% claim. Unit entries are visits/entries, not necessarily unique customers or jobs.

4. **The ownership need varies materially by powertrain.** [US DOE](https://afdc.energy.gov/vehicles/electric-maintenance) describes fewer engine-related maintenance needs for all-electric vehicles and potentially reduced brake wear from regenerative braking. [US DOE's HEV explanation](https://afdc.energy.gov/vehicles/electric-basics-hev) confirms HEVs have internal combustion engines. These technical facts don't establish Auto2000 visit frequencies, EV service margins, or the rate of customer defection. Model cohorts and actual work due must be measured.

5. **Battery information and after-sales retention already have established programs.** [Toyota Hybrid Health Check](https://aftersales.toyota.astra.co.id/hybrid-health-check) describes eligibility tied to age/mileage and periodic servicing, with a battery health certificate. [Toyota's 2026 T-CARE XTRA announcement](https://pressroom.toyota.astra.co.id/toyota-perkuat-layanan-purnajual-lewat-t-care-xtra) says services 8–11 are paid for by the customer and can extend warranty subject to terms. Whether a Digiroom flow improves discovery, service capture, or trade-in remains untested. Do not claim the dealer reimbursement for T-CARE is known.

## Competition economics from supplied case, p. 10

2025 case figures: Rp69 trillion revenue and Rp6.75 trillion gross profit. The sum of service, spare parts, and body/paint is Rp9 trillion in revenue (13.0%) and Rp3.15 trillion in gross profit (46.7%). This gives a case-based reason to model the full ownership relationship, but line-wide averages do not give EV-specific margins.

Illustrative structure, not measured uplift:
- incremental vehicle GP = additional deliveries attributable to intervention × realized dealer GP per delivery, adjusted for cannibalization.
- service GP = vehicles in cohort × jobs due per vehicle × Auto2000 capture share × GP per completed job.
- operating impact = incremental GP + realizable operating savings − ongoing operating costs; distinguish investment/cash timing from GP.

If users merely switch an existing booking from WhatsApp to Digiroom, booked volume alone does not establish extra GP. If digital assists a branch sale, app-only conversion can undercount its contribution. Baseline and counterfactual are needed.

## Open evidence gaps

Actual app-to-delivery funnel, EV-specific active-user base, service jobs due, capture and dealer GP, segment mix and competitor reasons, branch response and installed fleet age/mileage. Public sources cannot recover these internal denominators. No research finding in this note establishes causality.

