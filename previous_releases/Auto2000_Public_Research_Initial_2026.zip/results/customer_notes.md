# Digiroom customer voice and published usability research

Research date: 2026-11-11 (Asia/Jakarta). Evidence is a small convenience sample retrieved via web index, not a review census. Platform snippets have differing crawl ages and account/version coverage. Public narratives are reported experiences, not verified defects, current prevalence, actual completion, or economic impact. Do not publish usernames.

## Listing and sample records

- CV-01: Google Play listing, https://play.google.com/store/apps/details?id=id.co.astra.ai.dev1 . Developer describes home service booking/tracking, workshop scheduling, loyalty, catalog, credit simulation, and comparison. These are advertised capabilities, not verification of operation or adoption. Indexed listing showed 4.4 stars, 500k+ downloads and roughly 6.3k–6.6k reviews depending on locale/cache; snapshot differences and denominators prevent exact current claims. These downloads are not MAU or retention. Retrieved index: https://play.google.com/store/apps/details?hl=id&id=id.co.astra.ai.dev1 .
- CV-02: Google Play visible review dated 10 March 2026: reviewer says service booking available, but complains that service history and spare parts catalog are incomplete and says enabling Android developer mode prevented app access; says they prefer an older channel. This is one account, app version/device and current behavior unverified; do not independently assert feature absence. Source CV-01.
- CV-03: Google Play review dated 12 July 2026 praises ability to view service history. This does not negate CV-02 because basic availability and completeness, account context, version, and date can differ. Source CV-01.
- CV-04: Google Play Indonesian listing review dated 26 August 2026 says being able to choose the service time is convenient and helps avoid waiting. The account does not establish all appointments proceed on schedule. Source https://play.google.com/store/apps/details?hl=id&id=id.co.astra.ai.dev1 .
- CV-05: Google Play Indonesian listing review dated 24 June 2026 complains about branch amenities, not software; an 12 August 2026 developer reply promises evaluation. Do not code this as a digital defect or assume the concern was resolved. Source same Indonesian listing.
- CV-06: Apple App Store Indonesian listing, https://apps.apple.com/id/app/auto2000-digiroom/id421805050 , provides advertised services and an old 2022 positive review; another visible 2021 account reports pictures not showing following an update. Both predate the relaunch and are not evidence about current version. The separate US listing is a different geographic rating cohort.
- CV-07: Reddit https://www.reddit.com/r/indocartalk/comments/1pf1ffo/bagi_pemilik_mobil_brand_china_hows_the_aftersales/ includes one owner describing straightforward BYD service booking through an app. Anecdotal benchmark only; car, service, and jurisdiction are not matched to an Auto2000 booking walkthrough.

## Published user study, independent historical context

Sihombing, R. F., & Suarli, P. P. (2023), “Evaluasi Usability Pada Aplikasi Digiroom by Auto 2000 Dengan Menggunakan Metode Usability Testing”, Indonesian Journal of Computer Science 12(6), https://ijcs.net/ijcs/index.php/ijcs/article/download/3506/331/3214 . The paper reports five participants in a service task and separately 100 SUS responses with average 74.2/100. It reports participants' historical experiences of mismatch between app and receipt, difficulty with service history, and app errors. Authors attribute mismatch to a branch discount not reflected in app; their mechanism is reported as study interpretation, not independently validated. Source explicitly says five observed participants, so do not treat task test as 100 people, generalize to current app or interpret SUS 74.2 as 74.2% satisfaction. Follow-up test must inspect current version, actual timing and whether data changed due to job completion, discounts or branch systems.

## Candidate decision-relevant investigations

1. Check whether historical ownership records give enough context when shopping for service/trade-in, and explain when history becomes final. Different reviewers report availability and lack of completeness; reconcile version and account.
2. Test a transparent provisional quote and updated branch invoice as a consistent workflow, but first determine how common and material discrepancies are. Historic paper is not proof of current widespread issue.
3. Service slot choice may already offer value. Test if slot choice corresponds to an actual confirmed appointment and whether digital routing reduces work or just shifts channels. No valid causal estimate from reviews.
4. Investigate data protection/user access friction under supported device settings only where feasible; an individual complaint does not justify disabling security or identify proportion blocked.

## Coverage notes
One Play listing, one Apple listing, one historical study, one Reddit thread; review selection platform-controlled, exact app build unknown, small convenience sample, multiple current source snapshots have inconsistent counts. No app installation, logged-in testing, actual user interviews, sentiment census, contact, or booking was performed. Public privacy and third-party content rights limit redistribution; use brief paraphrases and URLs rather than full scraped reviews.
