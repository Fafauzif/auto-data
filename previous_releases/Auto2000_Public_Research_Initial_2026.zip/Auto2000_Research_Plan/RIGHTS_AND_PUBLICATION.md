# Rights and publication boundary

This package contains original research planning and brief observations, with links to third-party sources. No blanket license is asserted over those sources, trademarks, source code repositories or the user's private attachments. Tool code has not been vendored. Preserve upstream licenses if later importing dependencies. Public accessibility does not imply unrestricted republication.

Before public release of later collected data, review quotation limits, personal identifiers, contractual restrictions and source-specific reuse rights. Prefer derived facts, compact extracts and locators to whole-site republication. This is a research-package design rule, not a claim that a legal review has been completed.
