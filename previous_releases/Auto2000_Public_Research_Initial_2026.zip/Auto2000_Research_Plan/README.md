# Auto2000 discovery research: plan before scale

Status: PLANNING ONLY. Broad execution is paused pending review and an explicit instruction to start.
Prepared 10 November 2026, Asia/Jakarta. Version 1.0.

## The brief
Develop broad, evidence-led understanding of Auto2000's public digital ecosystem and its competitive context, then use that understanding to strengthen the IBSC 2026 case. Do not preselect low engagement, UI friction, SEO, or any other explanation as the main problem. Use resources already available and accessible public sources. No paid services, new accounts, or private account access are assumed.

The user wants a substantial preliminary collection design, a later large research run, distinctive business insights, and a GitHub-ready ZIP. This package is that design and handoff, not a completed audit or a million-record dataset. Existing exploratory observations are isolated from the future collection protocol.

## Read in this order
1. `docs/01_RESEARCH_CHARTER.md`: decisions, boundaries, open questions.
2. `docs/02_RESEARCH_MATRIX.md`: what to investigate and what evidence can answer it.
3. `docs/03_COLLECTION_PROTOCOL.md`: stages, sample design, quotas, failure handling.
4. `docs/04_TOOL_ASSESSMENT.md`: Agent Reach, Claude SEO, alternative tools and integration choices.
5. `docs/05_DATA_ARCHITECTURE.md`: units, identifiers, provenance, relationships and storage.
6. `docs/06_UX_AND_COMPETITOR_PROTOCOL.md`: reproducible journey and benchmark testing.
7. `docs/07_SEO_AND_CONTENT_PROTOCOL.md`: crawl, search, content, local and AI discovery work.
8. `docs/08_CUSTOMER_AND_MARKET_PROTOCOL.md`: public commentary, app evidence, audiences, market context.
9. `docs/09_INSIGHT_LAB.md`: distinctive insights and disconfirmation, adapted to the supplied mentoring notes.
10. `docs/10_ANALYSIS_AND_ECONOMICS.md`: how evidence will support business decisions.
11. `docs/11_EXECUTION_GATES.md`: resource envelopes, checkpoints, stop/scale rules and approval questions.
12. `docs/12_DELIVERY_AND_GITHUB.md`: reproducibility, reporting, repository design and publication limits.

Supporting files: config, schemas, CSV instruments, preliminary notes, a source register, offline validation and packaging scripts. None of the scripts collect data or launch an audit. No dependencies need installing to inspect this package.

## Three principles
Breadth before commitment: investigate competing explanations and non-EV journeys too.
Depth where it changes a decision: count independent evidence rather than decorative data points.
Traceability before storytelling: every eventual claim must link to observations, counterevidence and an explicit boundary.

## Current authorization
Allowed now: read supplied documents, research tools, design the study, preserve already collected exploratory evidence and create this package. Not allowed yet: a large crawl, extended social collection, automated audit campaign, paid requests, account/session import, production form submissions or GitHub publication. The ZIP can be uploaded by the user; creating it does not publish it.

## How to use
Review the plan and answer `DECISIONS_FOR_USER.md`. Later, authorize a named stage with a concrete resource envelope. Run `python3 scripts/validate_package.py` for an offline integrity check. The future collector is deliberately not implemented here; the execution specification is ready to turn into bounded code after approval.
