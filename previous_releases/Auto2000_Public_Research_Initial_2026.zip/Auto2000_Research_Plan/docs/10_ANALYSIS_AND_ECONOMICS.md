# 10. Analysis plan and business implications

## Descriptive before causal
First produce inventories, distributions, inconsistencies, coverage maps and journey observations. Then build interpretations with rival explanations. Public evidence rarely identifies a causal transaction uplift. Do not regress page issue counts against made-up conversion estimates or infer causality from review sentiment. Statistical complexity cannot repair missing outcome data.

## Planned analytical outputs
1. Template and information architecture map, showing source families and ownership.
2. Job-to-capability map: existing features, findability, information inputs, handoff and untested fulfillment.
3. Consistency graph linking model/year/variant/location facts across catalogue, overview, comparison, financing, schema and editorial.
4. Search-intent coverage matrix, separating observed visibility from unmeasured search demand.
5. Public customer narrative map with source mix, counterexamples and sampling limits.
6. Matched competitor mechanism comparison by customer job.
7. Technical issue families by eligible tested pages, with raw/rendered differences.
8. Local branch capability and discovery map where published data permits.
9. Evidence-weighted insight shortlist and explicit unresolved questions.
10. Opportunity portfolio with feasibility and break-even requirements, not invented ROI.

## Reconciliation and calculations
Define denominators before percentages. Report both “tested pages with this condition” and “eligible tested pages.” Do not extrapolate three child sitemaps to all sitemaps without an adequate design. Count repeated boilerplate separately from unique content. Distinguish unavailable from failed checks. Stratify by template before comparing issue prevalence; a large adviser family can dominate an unweighted total.

For prices, join only comparable model/year/variant/colour/location/offer/validity fields. A price difference may be legitimate; mismatches become review flags until terms are reconciled. For technical specifications, validate units and semantic field types before comparing numbers. Retain source versions instead of overwriting apparent conflicts.

## Economic bridges for the IBSC case
Potential vehicle-sales effect: eligible opportunities × truly incremental change in fulfilled-purchase probability × realized dealer GP per delivery. Potential service effect: installed vehicles × jobs due × change in Auto2000 capture × GP per job, evaluated by job and cohort. Potential efficiency effect: comparable volume × labor/time saved × economically realizable cost value, minus extra operating costs. These are model structures, not measured parameters.

Treat channel migration, product substitution, discounts on pre-existing demand, partner share and displaced capacity explicitly. A rise in Digiroom share alone may generate zero additional transaction GP. Useful digital assistance may close at a branch, so last-click digital purchases alone can understate contribution. Both possibilities must remain open.

Keep GP uplift separate from operating return and cash requirements. Investment costs and recurring costs may have different accounting treatment; state it. Use the case's business-line margins only at their proper scope; service's average margin is not a verified EV-specific margin. No precise revenue opportunity can be inferred from public traffic guesses.

## Opportunity sizing with unavailable inputs
Show break-even thresholds or conditional scenarios. Example structure: required incremental completed transactions = incremental programme cost / net contribution per incremental transaction, with clear treatment of fixed/variable costs and substitution. Do not present assumed conversion, customer base or margin as actuals. Downside/base/upside should be internally coherent and labeled illustrative; they are not confidence intervals.

## What makes the result useful for judges
Use the actual case rubric and constraints; avoid inventing judge scores. Lead later with the supported business problem and a few insights, then show methods underneath. Link each proposed initiative to its specific evidence and counterfactual. Keep broader discovery in appendices or a research companion. A website audit may inform the case without explaining the entire business problem.
