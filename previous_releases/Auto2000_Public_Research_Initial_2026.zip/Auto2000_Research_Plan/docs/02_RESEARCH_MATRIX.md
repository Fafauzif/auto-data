# 2. Decision-linked research matrix

Use this matrix to preserve breadth. Questions may be revised after the pilot; record whether each arose before or after looking at evidence.

| Track | Research question | Evidence and unit | Rival explanation to preserve | Decision affected |
|---|---|---|---|---|
| Business model | Which digital jobs connect to each 4S revenue/GP line? | Case accounting, public service/offer records; business line and transaction | Useful contact may create offline value invisible to web attribution | Where to invest and measure |
| Market and product | Is demand shifting toward offers Toyota/Auto2000 can serve competitively? | Dated model, price, powertrain and market tables | Availability, credit or model fit may dominate UX | Product targeting versus digital fixes |
| Audience | Who uses, influences, funds and fulfills each decision? | Public task evidence; later direct research if supplied | The browser user may not be buyer, payer or owner | Journey, content and handoff design |
| Discovery | Can people find the relevant offer or answer? | URL inventory, search samples, links, query intent | An answer may exist but sit on another Toyota property | Architecture and cross-site connection |
| Decision support | Can users understand alternatives and trade-offs? | Comparison, financing, warranty, ownership-cost tasks | Users may prefer an adviser even with complete information | Self-service versus assisted value |
| Transaction | What steps precede inquiry, booking or purchase? | State-by-state journey observations | Qualification steps may be necessary to fulfill correctly | Form simplification and branch routing |
| Ownership | What real occasions bring owners back? | Maintenance, damage, warranty, parts and replacement evidence | Quiet periods may reflect low need rather than dissatisfaction | Cadence and retention proposition |
| Operations | Does a digital promise connect to a fulfillable branch task? | Branch capability and scheduling representations | Real capacity cannot be inferred from displayed options | Promise clarity and execution tests |
| Trust | Is information coherent, current and accountable? | Cross-template facts, consent, pricing and reviewer evidence | Differences may be legitimate by year, variant or locality | Source-of-truth governance |
| Accessibility | Can varied users complete key tasks? | Automated checks plus manual keyboard/screen-reader protocol | Automated failures do not measure all real disability barriers | Inclusive UX backlog |
| SEO technical | Are important public pages discoverable and interpretable? | Robots, sitemap, raw/rendered metadata, links, structured data | Search engines may render or consolidate successfully | Technical fixes and indexation validation |
| Content | Does each page satisfy its actual promise? | Article/offer samples, evidence specificity, freshness | An introductory explainer need not provide a full purchase model | Update, consolidate or connect content |
| Local | Can a customer select the right branch for the job? | Department hours, capabilities, locations and directions | Generic copy may coexist with accurate operational data elsewhere | Local-information model |
| Competitors | Which mechanisms differ on equivalent jobs? | Matched journey benchmarks, terms and actual availability | OEM and dealer sites have different mandates | Transferable ideas and trade-offs |
| Public customer voice | What choice sequences and workarounds appear? | Deduplicated public reviews, comments, transcripts | Vocal users and algorithmic ranking select unusual experiences | Questions for validation and service recovery |
| Performance | Do pages render and respond reliably across contexts? | Repeated controlled lab tests; public field data if available | Geography, CDN, device and network can change results | Measured performance improvements |
| Measurement | What can and cannot be attributed publicly? | Public evidence plus case baseline, no private analytics assumed | Digital assistance may close offline | Future instrumentation specification |

## Research priority without premature diagnosis
Prioritize source acquisition by decision value, uncertainty, expected yield, access feasibility and cost. Do not prioritize hypotheses by how exciting their eventual solution sounds. Cover every material branch in the pilot before deeply expanding a favorite branch.

Each track receives: a bounded instrument, a source register entry, an analysis unit, a missingness rule, a disconfirmation question and a stopping condition. Use a common evidence ledger so cross-track synthesis does not mistake the same product database for several independent sources.

The website can establish visible design, published offers, structural relationships and represented process. It cannot establish actual user demographics, session funnels, customer motivations, completed sales, workshop capacity or realized margins. Public customer narratives can generate explanations; they cannot fill those internal denominators.
