# 9. From many observations to distinctive business insight

This protocol applies the supplied Mentoring Notes and BCC Hub v3. The standard is specific, decision-relevant reasoning, not novelty theater or framework quantity. The housing examples in the notes illustrate method; they do not diagnose Auto2000.

## Insight record
Each candidate must include: scoped observation; source IDs and independence; proposed mechanism; affected actor/segment; actual or plausible trade-off; strongest rival explanation; disconfirming evidence sought; boundary; business consequence; decision affected; and next test. Keep observations, mechanisms and solutions in different fields.

Weak: “Customers want easy service.” Its opposite is implausible and it changes almost no decision. Better research question: “Which information is a customer willing to give up, and at what stage, in return for a credible service slot or estimate?” This is a question to investigate, not an established insight.

## Eight discovery lenses
| Lens | What to compare | What a useful insight might discriminate |
|---|---|---|
| Role separation | User versus buyer/payer/fulfiller | Whose uncertainty the experience must resolve |
| Stated need versus actual workaround | Published complaints and reported choices | Whether a workaround beats the proposed feature |
| Availability versus findability | Feature inventory versus task navigation | Build new capability versus connect existing capability |
| Information versus economics | Price clarity versus true affordability/product fit | Better explanation versus a different commercial offer |
| Digital promise versus delivery | Booking/quote representation versus branch dependencies | Interface change versus operational capability |
| Frequency versus value | Routine opens versus rare major decisions | Engagement target versus transaction-critical intervention |
| Local flexibility versus consistency | Central product data versus branch/adviser adaptation | Governance versus local responsiveness |
| Acquisition versus installed base | Current sales versus owner cohorts | New-sale growth versus retention/capture priorities |

These are lenses, not conclusions. Every lens must allow the answer “no material problem found.” Broaden or replace them if evidence reveals a mechanism outside the list.

## Synthesis workflow
1. Finish descriptive inventories and quality checks before creating a headline narrative.
2. Group observations by task, actor, place and time, preserving exceptions.
3. Identify tensions or boundary conditions, not just the most common keyword.
4. Draft several competing explanations for each tension.
5. Seek sources that could reject the preferred explanation.
6. Reconcile source dependence: five pages from the same product database are one lineage, not five confirmations.
7. Ask which management choice would change if the claim were true.
8. Develop a short list only after reviewing limitations and contrary evidence.

Use an exploratory/validation split where practical. For example, discover a suspected template inconsistency in one set, then select a fresh template-balanced sample to check its extent. Such validation can verify a pattern; it still does not prove customer or profit impact. Keep a dated log of hypotheses invented after seeing data.

## Acceptance checklist
- Is it specific to Auto2000, an identifiable actor/task and a meaningful condition?
- Does it connect a fact to a mechanism rather than merely restate a chart?
- Could a reasonable opposite be true, or does it reveal an economically consequential fact even if straightforward?
- Is its evidence stronger than a single screenshot or repeated press release?
- Have we sought the strongest contrary case?
- Does it distinguish a product, price, channel, operations or investment choice?
- Is the consequence material or explicitly still unquantified?
- Can a judge inspect the claim's provenance and limits quickly?

Do not manufacture numerical insight scores. Statuses are observation, exploratory explanation, corroborated pattern, bounded recommendation or unresolved. “Root cause” is reserved for evidence that supports a mechanism; otherwise use working explanation.

## Example candidate pathways, deliberately unproven
If model comparison exposes technical attributes but not an ownership trade-off, investigate whether better decision support would change a shortlist—or whether upfront affordability dominates. If buyers prefer WhatsApp, investigate whether conversation resolves exceptions—or whether the app has avoidable friction. If owners visit less, distinguish mechanical maintenance need, young vehicle cohorts and competitor capture. If repeated adviser pages exist, distinguish useful local acquisition from content maintenance cost or confusing source ownership. If service slots appear late, test whether earlier disclosure helps—or whether vehicle qualification is necessary to make availability honest.

None of these should become the main diagnosis merely because we saw an example during reconnaissance. Maintain an “interesting but unsupported” parking lot and a “rejected explanations” log alongside accepted claims.

## From insight to strategy later
After evidence review, develop materially different options including an operational alternative, a commercial alternative, a digital intervention and a simpler baseline where relevant. For each: description, problem evidence, benchmark/transfer limits, mechanism, economics, owner and test. A distinctive insight need not imply a globally new feature; a precise adaptation to this customer's decision can be more valuable than an elaborate invention.
