# 7. SEO, content and local discovery protocol

## Inventory and crawl
Validate robots syntax and path permissions; inspect the sitemap index and child files for valid URL entries, encoding, status, domain boundaries and meaningful dates. Separate syntactically valid XML from valid sitemap field data. Compare important crawlable pages with sitemap representation. Identify traps such as filter combinations, internal search, calendars, variant permutations and adviser syndication. No exhaustive crawl until URL families and budgets are understood.

## Raw versus rendered page checks
Extract HTTP status/redirects, title, description, robots meta, canonical, lang, viewport, headings, primary text, links, images and structured data from initial HTML. Repeat selected fields in a rendered state. Record missing, empty and conflicting values independently. Validate structured data syntax and semantics against current primary documentation before declaring errors. Product price, availability, ratings and model year must agree with visible content and actual variant scope. Do not recommend schema that describes something not present or not applicable.

Canonical absence alone is not proof of indexation failure. A canonical is a signal, not proof of Google's selected URL. Sitemap inclusion is not proof of indexing. A site-restricted search is not an index count. Confirmed current index status and search performance require appropriate access; absent that, retain a verification lead.

## Search-intent investigation
Build a balanced query set across brand navigation, generic model discovery, price/finance, powertrain comparisons, charging, maintenance cost, warranty, battery condition, resale, local service and emergency needs. Retain Indonesian phrasing, common abbreviations and ambiguous meanings; use English only where justified. Record query, engine, date/time, language, geography/device if controllable, result type, result URL and access method.

Compare page purpose with query intent. Search tool ordering must not be reported as measured Google rank. Do not infer traffic or keyword volume from result count or snippets. If no reliable free rank/volume source is available, deliver intent coverage and observed result examples without fabricated demand estimates.

## Content quality sampling
Stratify by template, topic, recency, adviser/national ownership and commercial relevance. For each page ask: what question did the title promise to answer; can the main text answer it; are facts model/year/location specific; which claims require an OEM source; does the CTA fit the reader's task? Record supporting evidence, dates, reviewer identity where public, update ownership and inconsistencies.

Test duplicate and near-duplicate families after removing boilerplate. Keep syndicated, canonicalized and genuinely local content distinct. Two matching pages do not establish a spam penalty. Compare cost guides for decision-useful assumptions and ranges, not arbitrary word counts. Long pages may be useful; short local pages may be useful too. Do not penalize a page merely for failing a generic word threshold.

## Local SEO
Inspect branch name, address, department hours, capabilities, service area, directions, contact route, public reviews and branch/adviser relationships. Sample showroom-only, workshop, body/paint and other advertised capabilities. Match structured data to real branch identity. Without access to a business profile, do not claim optimization status, map rankings or ownership. Publicly visible review totals can differ across platforms; record source and capture date rather than forcing reconciliation.

## Performance and images
Use three repeated lab tests per selected page/device/context when feasible; report distribution and configuration. Public CrUX, if available, is field data with its own aggregation scope and period. A lab result does not establish INP across real visitors. Missing PSI quota is a measurement limitation. Image filename/extension and raw HTML size do not establish transfer weight or page speed. Collect resource sizes, dimensions, loading behavior and waterfall evidence before proposing precise optimization benefits.

## AI discovery
Evaluate clear entity identity, attributable facts, stable URLs, coherent technical definitions and evidence-backed answers. Inspect AI search crawler policy separately from training crawlers using current vendor documentation. llms.txt or agent-related endpoints may be inventoried, but their presence is not evidence of ranking uplift or AI citations. If no controlled repeated query panel is available, do not assign AI share-of-voice percentages.

## Reporting
Deliver a template-level issue inventory, content/intent map, duplicate families, validated structured-data concerns, performance results or limitations, and a prioritized verification backlog. Avoid an overall numeric health score when major categories are unmeasured. Separate search-engine guidance, tool heuristics and analyst preferences.
