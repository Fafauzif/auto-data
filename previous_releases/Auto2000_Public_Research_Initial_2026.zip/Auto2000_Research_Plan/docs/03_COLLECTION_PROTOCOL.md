# 3. Collection stages and sampling

All numbers below are proposed ceilings, not promises, completed work or permission to run. Use the smallest sample that validates the instrument before expanding.

## Stage 0: freeze the protocol
Normalize the brief and input versions. Record domain roles, templates, permitted source types, required outputs and exclusion rules. Pin tool versions and inspect external scripts before executing them. Create a run manifest and cost ledger. Review current robots rules at run time; saved rules can become stale. Existing notes belong to a reconnaissance cohort and must not be counted as a fresh balanced sample.

## Stage 1: inventory without a page crawl
Fetch robots and sitemap indexes once per approved domain, then enumerate approved child sitemaps. Store declarations separately from verified URLs. Classify patterns into home, catalogue, category, model, variant, specification, image/interior, price/credit, editorial, promotion, city, branch, adviser, used vehicle, service and utility templates. Estimate scope before fetching bodies. Remove fragments from fetch keys but preserve them as navigation evidence. Preserve original URL, normalized URL and any declared canonical as separate fields.

Do not recursively follow every linked domain. Inventory reveals where the site is large and repetitive; it does not prove every listed URL exists, is indexed or needs detailed rendering.

## Stage 2: calibration pilot
Suggested ceiling: 60 Auto2000 public pages, 20 relevant pages across at most four comparison domains, 12 primary journeys on desktop and mobile, 100 public commentary items, 30 search-query/context combinations and 12 page/device lab-test cells. Each lab cell may have three repetitions, explicitly counted as repeats. Keep the whole pilot under 200 target-site HTTP requests and 40 rendered page loads, apart from browser subresources; if that is infeasible, revise the design rather than silently exceeding it.

Select pages by template and purpose, not just search prominence. Include EV and non-EV, shopper and owner, high and low price, recent and older content, national and local pages, and successful/ordinary cases alongside suspected issues. Deliberately include at least two branches with different advertised capabilities and two cities where feasible. If evidence needed for a stratum is unavailable, record the coverage gap.

## Stage 3: review yield before broad collection
Inspect parser correctness, metadata coverage, duplicate rates, true content extraction, source availability, reproducibility, storage per observation and unanswered questions. Manually reconcile at least 20 diverse extraction records against their sources; validate all high-consequence anomalies. Check whether a proposed field actually informs a decision. Remove expensive fields with little value; add missed fields before generating thousands of incompatible records.

Pilot progression criteria: every included template has a tested extractor or an explicit manual route; required provenance fields are populated; all failed requests retain a status and reason; no cookies/private data appear in export; raw/rendered differences are classified; cost and runtime estimates derive from actual pilot measurements. These are engineering gates, not proof that a hypothesis is correct.

## Stage 4: bounded expansion
Suggested first envelope after approval: up to 2,000 unique Auto2000 pages, 100 comparison pages, 100 matched query/context cells, 500 relevant public commentary items and 40 deeper journey scenarios. Apply stratified sampling to large repeated local/adviser/article families. Discovery inventory may exceed page-fetch limits; listing an URL is not fetching it. Escalate beyond this envelope only for material unresolved questions and a new resource assessment.

## Request discipline
Start at one request per second per domain and no more than two concurrent requests to a domain; honor stricter rules. Use capped exponential backoff and a maximum of two retries for ordinary transient failures. Stop a domain queue on persistent 429, confirmed bot challenge or repeated server errors. Do not rotate proxies or fingerprints to force access. A bare 403 is an access failure of unknown cause, not evidence of a customer-facing site defect. Respect login and purchase boundaries. Cache successful retrievals and resume via checkpoints rather than refetching entire cohorts.

## Sample integrity
Record selection method, inclusion probability if known, unavailable strata, dates and locales. Convenience public reviews remain nonrepresentative at any size. A repeated spec across 200 variants is not 200 independent facts. Where reporting counts, show eligible sampled pages and successful observations separately; inaccessible pages are neither failures of the site nor clean passes.

## Stop conditions
Stop when marginal new evidence no longer changes the decision or distinguishes rival explanations; retain the residual uncertainty. Stop earlier if resource ceilings are hit, source access is restricted, timestamps/definitions cannot be reconciled, or extraction error makes expansion unreliable. No arbitrary claim of thematic saturation from a large scraped corpus.
