# 12. Deliverables, reproducibility and GitHub packaging

## This planning ZIP
Contains original planning documents, reviewed preliminary observations, source references, empty data-collection instruments, schema definitions, disabled run configurations and offline helper scripts. It excludes user-uploaded casebooks/coaching files, raw third-party HTML, private contacts, cookies, API tokens and cloned dependency repositories. The user may upload this ZIP to a repository. We have not created, uploaded or published a GitHub repository.

## Later research deliverables
1. Research README: scope, what was actually run, coverage and limitations.
2. Broad discovery report: business, audiences, UX, content, SEO, local, competitors and public customer voice.
3. Evidence ledger: observations with stable IDs and exact provenance.
4. Reproducible tables: page/template inventory, facts, links, journey states, content topics, commentary codes and benchmark matrix.
5. Insight book: small defensible shortlist, rivals, disconfirmation, economic consequence and next tests.
6. IBSC bridge: evidence-to-problem-to-option mapping, assumptions, gross-profit mechanics and budget constraints.
7. Action/validation backlog: owner/dependency, severity, effort basis and proof needed.
8. Run manifest, data dictionary, methods, exclusions, code versions and checksums.

The final ZIP is a portable project, not a dump of all collected bytes. Bulk artifacts can be referenced by hash and retention location. If full raw evidence cannot be distributed, preserve a brief lawful extract and a source locator, and explain the reproducibility limitation.

## Repository conventions
`docs/` for methods and reports; `config/` for reviewed run envelopes; `schemas/` for contracts; `templates/` for instruments; `data/curated/` for small sanitized samples only; `scripts/` for reproducible code; `manifests/` for lineage and hashes. Keep raw captures, caches, browser profiles and environment credentials excluded. A public repository should have a clear rights statement distinguishing original work from third-party material; do not place a blanket open-source license over content we do not own.

Large data does not belong directly in ordinary Git history. Evaluate existing artifact storage or a separate data-release mechanism only when real volume is known. Version manifests/checksums in Git and keep stable references to immutable data partitions. Do not promise a huge raw dataset fits GitHub's upload interface. Retain a compact release ZIP with documentation and curated evidence; document any external data dependencies.

## QA before release
Check every internal link; parse JSON/CSV; verify IDs and referenced evidence; test ZIP integrity; inspect for sensitive strings and session URLs; remove private source uploads; ensure no untested metric is represented as zero. Re-run dependent calculations after data updates. Validate claim counts and denominators, source dates and currency scopes. Review every high-impact claim against original evidence and counterevidence.

## Reporting style
Lead with the business finding when supported, not tool names. Put exact method details and data limitations near the relevant exhibits. Use tables for comparisons and a small number of meaningful visuals. Do not bury uncertainty in an enormous appendix. Follow BCC Hub's appendix-specific visual defaults only if later building appendices; they do not require designing a deck now.

## Reproducibility boundaries
Web pages, search results, inventory and personalized content change. An archived capture establishes what we observed, not eternal truth. Browser state and uncontrolled result geography limit repeatability. Transcripts, public reviews and syndicated pages have selection/dependence biases. Record these limits as part of the artifact, not as afterthoughts.

This package's offline validator checks local structural integrity; it is not an SEO validator, a scientific peer review or an executable collector. A passing result does not establish the truth of any future conclusion.
