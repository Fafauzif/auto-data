# 1. Research charter

## Outcomes
Produce an evidence base that helps distinguish where Auto2000 creates value, where customers encounter decision or fulfillment problems, how it compares with alternatives, and which opportunities deserve further validation. Connect those opportunities to the case's requirements: differentiated digital innovation, EV sales and after-sales gross profit, realistic assumptions, privacy, implementation feasibility and the Rp150 billion incremental investment cap for 2026–2028.

Broad discovery and case relevance are two linked outputs. The discovery report should retain interesting findings outside the eventual competition storyline. The case synthesis should select only the evidence that changes the actual strategic decision. A visually weak component may be commercially minor; a visually polished page may still fail a buyer's decision.

## Object of study
Primary: public Auto2000 website, its content templates, transactions up to safe pre-submission boundaries, local branches/advisers, website-to-app handoffs, and public Digiroom app information. Adjacent: Toyota OEM information, warranty/ownership programmes, trade-in and financing handoffs, relevant competitor sites and public customer discussions. External sites are separately scoped domains, not an unlimited crawl frontier.

Include the full 4S model: vehicle sales, service, spare parts, body and paint. Investigate individuals, families, existing owners, replacement buyers, first-time electrification shoppers, commercial/fleet customers and relevant influencers. These are potential audiences, not measured visitors. Geography begins with Indonesia; compare cities and branch types where visible evidence supports it.

## Questions to leave open
Is the principal issue commercial offer fit, affordability, category mix, discoverability, decision support, usability, local execution, customer trust, ownership cadence, channel substitution, data continuity, or something else? Does the answer vary by task, vehicle, customer stage and location? What does Auto2000 control directly? Which digital interactions deserve investment because they change a transaction or its cost?

Do not assume the mobile app matches the website. Do not infer the customer base from app users or site visitors. Do not treat an available feature as widely used, a competitor feature as successful, or a public complaint as common. Distinguish Toyota brand share, Auto2000 dealer share, digital attribution and incremental profit.

## Evidence contract
Maintain five states: supplied case fact, directly observed public evidence, derived calculation, interpretation, and modeled assumption. A sixth state, tested effect, is available only if an appropriate experiment or credible comparative study actually exists. The public-data run will generally locate mechanisms and candidate opportunities, not identify causal uplift.

Every substantial claim should specify population/task, period, geography, denominator, data lineage and the decision it changes. Unknown values remain unknown. Scores, prevalence and forecasts cannot be filled simply to complete an attractive report.

## Success for this research
A useful deliverable supports a small set of defensible, differentiated insights, documents credible rival explanations, identifies existing capabilities before proposing new ones, and makes limits easy to inspect. It also produces reusable datasets and reproducible methods. Success is not a prescribed number of pages, charts, frameworks, feature ideas or surprising headlines.

## Non-goals and operational boundary
No penetration testing, bypassing safeguards, mass lead submission, synthetic reviews, hidden private customer data, direct outreach or spend. Public staff information may establish an adviser or branch role; personal contact details are unnecessary to the public research corpus. Account credentials, cookies and private source documents do not belong in a public repository.

The current research is a planning exercise. It should not silently become an unattended overnight run because tools are available. The later run needs the user's explicit start instruction after reviewing the concrete scope.
