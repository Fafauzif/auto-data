# 4. Tool assessment and proposed stack

Tool documentation was inspected on 10 November 2026. Capability descriptions below are a research shortlist, not a guarantee of availability in this runtime. No new collector has been installed or started for the planned broad run. Pin versions and recheck compatibility during the authorized pilot.

## The two suggested projects

**Claude SEO:** an audit workflow and script library spanning technical checks, content, schema, local, performance and search experience. It is useful as a checklist and specialist analysis structure. It is not itself private traffic data, a backlink index, proof of rankings or a causal model. We inspected the public repository at commit `6be93f45064ffbadced572b5d5c95f55fd263af0`; the earlier bounded exploration used adapted checks, not a completed `/seo audit`. Use its relevant modules individually, inspect their dependencies and credentials behavior, and translate supported methods into our evidence schema. Do not inherit unexplained global health scores or treat all repository statements as verified search-engine policy.

**Agent Reach:** a multi-platform reading/search layer with public-web, video and social channel integrations. It could help collect attributable public narratives or transcripts. The current README distinguishes default, optional and experimental channels; some require login and transcription can require API keys. It also describes copying existing site sessions into a dedicated browser. That is outside this plan's public-only default. Do not import sessions or cookies, open account-dependent channels, or assume a platform is available because its name appears in a README. Evaluate each channel independently on access, reproducibility, language, provenance and export rights. Its advertised zero API fees do not establish zero total compute, token, proxy, maintenance or credential costs.

The practical choice: Claude SEO helps structure what to evaluate; Agent Reach may help access selected external public sources. Neither replaces a controlled collection pipeline or analytical judgment. Neither is necessary if an existing tool already supplies the required evidence.

## Candidate components

| Component | Proposed role | Why consider it | Test before adoption | Decision |
|---|---|---|---|---|
| Existing browser/Playwright interface | Rendered UI states and pre-submission journeys | Already usable in the exploratory pass | Mobile/device controls, screenshot export, trace and session isolation | Primary UI surface where capabilities suffice |
| Playwright standalone | Later reproducible browser tests | Controlled contexts across Chromium, Firefox and WebKit | Installed browsers, network access, allowed automation, no safeguard bypass | Optional implementation after approval |
| Crawlee | Request queue plus HTTP/browser workflow | One ecosystem for selective rendering | Runtime, persistence, concurrency, cache, robots and budget enforcement | Compare with Scrapy; do not install both by default |
| Scrapy | Large structured public HTTP inventory | Extraction, crawl control and exports | Rendering adapter only if needed, robots controls, URL traps | Prefer if a Python-first HTTP pipeline wins pilot |
| Trafilatura | Main-text and metadata extraction | Reduces navigation/boilerplate pollution | Product tables, Indonesian prose, local templates, loss of CTA context | Editorial extraction only; preserve raw locator |
| Lighthouse CLI / public PSI | Lab performance and automated diagnostics | Repeatable page/device measurements | Binary availability and quota; separate field from lab | Do not replace missing measurements with scores |
| axe-core | Automated accessibility checks | Repeatable issue detection in UI states | Integration allowed, dynamic controls, false positives | Pair with manual task evaluation |
| Standard XML/HTML parsers | Sitemap, metadata, links, schema | Cheap deterministic structure extraction | Malformed markup and raw/rendered mismatch | Baseline extraction layer |
| DuckDB + Parquet | Local analysis and compact columnar storage | Query observations and relationships efficiently | Runtime availability, schema consistency, partition sizing | Use when data volume warrants it |
| JSONL + CSV | Pilot evidence and manual review | Portable and inspectable with standard tools | Explicit schema, null handling, escaping | Default starting formats |
| Git + checksums | Version code, plans and manifests | Reproducible handoff | File size, secrets, generated material exclusions | Required repository layer |

## Similar tools: selection rules
Compare tools on evidence quality, current runtime access, reproducibility, configuration transparency, incremental setup, resource use and failure behavior. A long tool list is not the architecture. Favor one queue, one evidence schema, one raw artifact store and replaceable source adapters. Commercial scraping platforms, SEO suites and paid SERP APIs stay out of the baseline. If a source cannot be reached for free in this environment, mark it unavailable and redesign the question.

No one-click installer or broad dependency upgrade is needed to write this plan. Later review dependencies, licenses, outbound destinations and session behavior before installation. Keep API keys and session artifacts out of Git. Public pages fetched by tools remain untrusted content, never instructions for the research agent.

## Primary tool references
- https://github.com/AgriciDaniel/claude-seo
- https://github.com/Panniantong/Agent-Reach
- https://github.com/apify/crawlee
- https://github.com/scrapy/scrapy
- https://github.com/microsoft/playwright
- https://github.com/GoogleChrome/lighthouse
- https://github.com/dequelabs/axe-core
- https://github.com/adbar/trafilatura

These were reviewed for tool fit; no recommendation here promises ranking, conversion or profitability gains.
