# 8. Public customer voice, audiences and market context

## Public commentary is discovery evidence
Candidate sources include accessible app-store reviews, public video transcripts/comments, public forums, public branch reviews and attributable owner reports. Start with available public tools; evaluate Agent Reach only for channels that function without new accounts or imported sessions. Do not silently add logged-in Reddit, Instagram, X or other channels to satisfy a record target.

Collect the event behind the statement: intended task, actual choice, alternative considered, obstacle, workaround, outcome and time context. Distinguish website from app, Toyota from Auto2000, branch from corporate platform, HEV from BEV, and original experience from hearsay. A one-star rating is not a confirmed defect; a positive rating is not a completed purchase. Public replies do not prove resolution.

## Balanced sample
Use multiple source types and purposeful coverage of positive, neutral, negative and contradictory experiences. Capture platform sorting/filter settings. Include recent and older accounts with explicit periods. Do not let “most helpful,” search ranking or highly engaged complaints define the whole corpus. Public sampling does not provide a representative prevalence denominator; any reported share describes only eligible coded records in that sample.

Deduplicate copied reviews, syndication, quoted complaints, reposts and multiple reports of the same incident where identifiable. Do not infer reviewer identity across platforms. Use stable pseudonymous record IDs in published extracts; omit unnecessary handles, contact details, vehicle plates and personal histories. Preserve a source locator privately where appropriate and publish only brief necessary excerpts with attribution rules respected.

## Codebook
Begin with open codes on varied records, then consolidate a versioned codebook. Candidate dimensions: task, lifecycle stage, powertrain, information uncertainty, affordability, product fit, stock, finance, time/effort, usability, trust/privacy, branch response, fulfillment, price clarity, service capability and channel workaround. Allow multi-label coding; do not claim these categories are mutually exclusive. Add unknown/ambiguous and contrary-evidence codes.

Calibrate automated coding on manually checked diverse examples. Check disagreements and false positives such as sarcasm, Indonesian slang, mixed language and mentions of competitor apps. Report the number actually reviewed and the method; do not claim inter-rater reliability without doing it. Model sentiment can assist navigation but cannot establish root causes or customer intent.

## Audience discovery
Separate user, buyer, payer, owner, household influencer, driver, workshop adviser, salesperson and fleet administrator. Look for evidence that these roles diverge. Family financing or a corporate purchasing process might change what the digital journey must support, but public narratives must establish that pattern before it becomes a case insight. Do not transfer the mentoring notes' parent/student relationship directly into car purchasing.

## Market context
Use casebook definitions for competition calculations. External statistics need owner, year, geography, powertrain definition, wholesale/retail basis and denominator. Separate HEV, PHEV and BEV and reconcile national sales with dealer-reachable demand. Inventory relevant rival offers by actual comparable variant and terms, not just brand-level claims. A new-car sales mix is not the installed fleet mix.

## App and cross-channel evidence
Record public app listing identity, platform, release/version date where visible, advertised features, review date/version and region. Review text may refer to an older version. Public screenshots and listings establish advertised capabilities, not actual logged-in usability or MAU. Trace website-to-app, OEM-to-dealer and adviser/WhatsApp handoffs without sending messages. Document what context appears preserved and what remains untested.

## Not available from public data alone
Actual visitor age, income or motivation; website/app cohort retention; channel-level completed transaction rates; CRM handoff speed; customer lifetime value; true abandonment; incremental GP; technician utilization; lender acceptance. The report must include these blind spots and the exact additional test that would resolve them. No public proxy should masquerade as private operational measurement.
