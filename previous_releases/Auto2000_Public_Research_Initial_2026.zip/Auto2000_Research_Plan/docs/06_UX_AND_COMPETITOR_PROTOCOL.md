# 6. UI/UX, audiences and competitor protocol

## Measure jobs, not just screens
Record the user goal, prior knowledge, current ownership, decision stage and information available before each task. Separate evaluator walkthroughs from usability research with actual participants. This public-only plan can inspect the interface but cannot measure real task-success rates, satisfaction or demographic differences without participants.

| Journey | Starting condition | Intended safe endpoint | Questions |
|---|---|---|---|
| Find a suitable car | Budget, household needs, usage known | Shortlist with reasons | Can filtering reflect real constraints? |
| Compare HEV and ICE | Two relevant variants | Explain trade-off | Is comparison useful beyond raw specifications? |
| Evaluate BEV fit | Home charging may/may not exist | Identify costs, constraints, next step | Is fit distinguished from generic enthusiasm? |
| Understand finance | Price and illustrative DP known | Estimate initial cash and installments | Are assumptions, fees and terms intelligible? |
| Request test drive | Specific model and locality | Inspect available branch/date/time; stop before submit | Is scheduling a request or confirmed reservation? |
| Plan workshop service | Vehicle, age and mileage known | Inspect prerequisites, jobs, estimate and booking flow | What must be provided before availability is visible? |
| Use home service | Owner with location constraints | Understand scope and request requirements | What work and geography are eligible? |
| Buy parts/accessories | Known vehicle/task | Identify compatible product and total-cost cues | Are fitment and returns clear? |
| Repair body/paint | Damage/insurance uncertainty | Find scope and appropriate branch | Is the right department discoverable? |
| Trade in | Owned model/year/mileage | Inspect estimate mechanism and assumptions | Does an estimate preserve uncertainty and next-step clarity? |
| Find branch/adviser | Task and locality known | Select plausible location/person | Are hours and capabilities task-specific? |
| Return after delivery | Owner needs warranty/history/tracking | Inspect public explanation and login boundary | What requires app/account, and why? |
| Fleet/commercial | Multi-vehicle need | Find credible specialist route | Does consumer navigation obscure B2B support? |
| Ask for help | Known uncertainty | Find help route without sending a message | What context is preserved into human assistance? |

Do not enter invented customer contact data, plate numbers or bookings to force completion. If validation cannot be inspected safely, mark the downstream state untested. Synthetic finance inputs are illustrative scenarios, not the user's finances; avoid optional sensitive fields when unnecessary.

## State capture contract
For each scenario record start URL, exact final URL, steps, controls used, visible output, viewport, locale, device, location setting, account state, consent state, validation/errors, and any interruption. Capture initial loading and settled state separately; do not call transient skeletons broken pages. Count steps only with a definition: navigation, data-entry action, and system wait are different. Record effort and information required, not only click count.

Evaluate hierarchy, visual consistency, legibility, content density, competing CTAs, terminology, feedback, reversibility, error prevention, contextual help, price clarity, privacy choices and handoffs. Give each issue a customer consequence and evidence reference. Aesthetic preference is labeled as judgment. Rating severity requires task impact and recurrence; it is not a measured conversion penalty.

## Device/accessibility matrix
Propose a narrow-mobile viewport, common mobile viewport, tablet and desktop; choose exact sizes at pilot time and record them. Test zoom, keyboard traversal, visible focus, dialogs, accordions, sliders, labels, contrast and error announcements. Inspect touch target sizes and horizontal overflow. Automated axe checks complement manual review; no automated pass proves WCAG conformance. Repeat key mobile checks on real devices only if such access exists; emulator output is labeled as emulation.

## Benchmark groups
1. Same-job dealer comparison: a relevant Toyota dealer and an EV dealer if accessible.
2. OEM comparison: Toyota and a competing brand's public product/test-drive experience.
3. Mechanism comparison: a clearly useful financing, service, trade-in or ownership-information pattern.

Do not rank entire brands from one page. Match task, geography, language, account state, device and offer class. OEMs often educate and route to dealers; dealer sites also fulfill local transactions. Evaluate within those mandates. Record both things Auto2000 does better and competitor weaknesses; attractive imagery is not evidence of better economics.

Use `templates/journey_matrix.csv` and `templates/competitor_matrix.csv`. Keep “not observed,” “not offered,” and “could not access” distinct. Feature absence requires an adequate search of the relevant journey, not a missing homepage icon.
