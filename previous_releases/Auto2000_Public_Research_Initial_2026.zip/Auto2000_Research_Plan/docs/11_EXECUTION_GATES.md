# 11. Execution gates, resource budgets and remaining decisions

## Current state
Planning package ready for review. Large run NOT authorized. The user has answered: combine broad discovery with IBSC relevance; use only already accessible resources/public information; no paid tools or additional access requirements. Do not reopen those settled preferences.

## Proposed sequence and outputs
| Gate | Work | Output | Requirement to continue |
|---|---|---|---|
| A: plan review | This package, tool comparison, research instruments | Concrete scope and budget | User answers execution questions and authorizes pilot |
| B: instrument pilot | Bounded calibration sample | Extraction QA, source coverage, runtime/size measurements | Required provenance, reliable extraction, resource fit |
| C: preliminary data collection | Balanced inventory and evidence sample | Discovery tables, contradictions, coverage gaps | User reviews meaningful scope changes; no automatic massive expansion |
| D: expanded collection | Named domain/source envelope only | Versioned corpus and analysis tables | Resume budget fits remaining runtime/storage; access permitted |
| E: synthesis | Independent review, rival tests, economics | Insight shortlist and case relevance | Each major claim traceable and qualified |
| F: release | Sanitize, validate, package | GitHub-ready research ZIP and report | No private/copyright-heavy raw corpus in public bundle |

Stages B and C may be combined into a single bounded pilot if it is clearer. A new approval is needed for a material scope or spending change, not every reversible read within the approved envelope.

## Resource envelope
Prefer source-level HTTP extraction and local deterministic checks; render only sampled interactive/dynamic pages. Do not send every raw page to an LLM. Deduplicate before semantic coding. Use summaries for triage, then inspect original evidence for accepted claims. Cache artifacts, checkpoint queues and track request counts, wall time, tokens when exposed, storage and unavailable sources.

Planning ceilings in config: pilot 60 primary pages, 20 comparison pages, 100 commentary items, 30 search cells, 12 journey scenarios and 12 lab cells. First expanded envelope: 2,000 primary pages, 100 comparison pages, 500 commentary items, 100 search cells and 40 scenarios. These are proposed limits, not minimums. Browser subresource traffic must be measured separately; a page-load cap does not bound every network request.

No prepaid API credit, proxy purchase, paid dataset or new account is assumed. If a free endpoint is quota-limited, mark the cell unavailable, use an already-supported local route if appropriate, or omit it. Do not spend to make a report look complete.

## Unattended execution
“Run for hours” expresses desired depth, not a guarantee that this conversational host can keep a process alive after the turn. Before starting, establish available foreground/background execution, maximum wall time, checkpoint persistence, resumability and the actual collection surface. Do not create a scheduled automation or claim an overnight run is active without a supported mechanism and authorization. Prefer bounded resumable batches with progress files over one opaque long process.

Suggested planning checkpoints: after inventory, after the first 10 extraction records, after the pilot, at each 250 fetched pages and before synthesis. These checkpoints are logical review points, not messages that require waking the user at every step. Stop on constraints; persist useful partial output.

## Stop/scale criteria
Stop when access fails persistently, a bot challenge is confirmed, rate limits persist, extractors corrupt key fields, storage is insufficient, source terms prevent the planned reuse, or collection no longer distinguishes material explanations. Scale when newly added strata yield decision-relevant evidence and incremental cost is justified. Do not scale simply to reach millions of records.

## Approval prompt for the next turn
“Use version 1.0 of this plan. Start the bounded pilot only [or name another stage]. Use public accessible sources and existing resources. Cap the run at [scope and wall time], preserve checkpoints, and return evidence quality, gaps and a recommendation for expansion.”

If only a vague “go” arrives, interpret it against the concrete proposed pilot rather than the maximum imaginable run. The latest explicit restriction—no large run before reviewing the plan—remains active until the user changes it.
