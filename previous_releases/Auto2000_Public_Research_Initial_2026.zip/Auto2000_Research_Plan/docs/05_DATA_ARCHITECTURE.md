# 5. Data architecture and provenance

## Do not confuse the units
One source is not one page; one page is not one visitor; one observation is not one customer; one extracted attribute is not one independent insight. A million link rows can arise from repeated navigation on a few thousand pages. Report these quantities separately: discovered URLs, fetched unique URLs, page states, source documents, unique narratives, coded segments, extracted attributes, link edges, requests, repeated measurements and accepted insights.

Example of scale arithmetic only: 2,000 pages × 150 scalar attributes = 300,000 attribute values; 2,000 × 200 links = 400,000 link occurrences. Neither creates 700,000 independent pieces of customer evidence. Deduplicated source diversity and decision coverage matter more than the combined total.

## Logical tables
| Table | Grain and key | Important fields |
|---|---|---|
| runs | One authorized run; run_id | scope version, stage, budgets, start/end, tool versions, status |
| sources | One source entity; source_id | owner, source class, geography, access mode, rights, independence cluster |
| urls | One discovered URL; url_id | original/normalized URL, template, parent, discovery path, sample stratum |
| fetches | One request; fetch_id | run_id, url_id, time, method, status, redirect chain, error, bytes |
| page_states | One rendered state; state_id | fetch_id, device, viewport, locale, location selection, consent, actions |
| observations | One scoped fact; observation_id | source, locator, field/value/unit, evidence kind, state/time, extraction method |
| links | One link occurrence | from state, destination, anchor, position, relation, repeated-template flag |
| entities | One model/variant/branch/service/programme | stable ID, aliases, temporal validity, ownership |
| claims | One analytical statement; claim_id | observation IDs, mechanism, rival, boundary, status, decision |
| experiments | One proposed future test | eligibility, counterfactual, measure, feasibility, stop/scale criteria |
| artifacts | One stored file | path, SHA-256, bytes, content type, retention, publication permission |

IDs must not depend on row position. Prefer stable deterministic hashes of normalized identifiers plus meaningful version/time keys. Separate entities from their changing facts: a price belongs to a variant, location, colour, programme and time, not just a model name. Preserve model year separately from publication year and capture date.

## Minimum provenance
Every observation needs a source URL or supplied-file locator, capture time/timezone, evidence state, selection method, tool/parser version, relevant page state, exact scope and a reproducible locator. For calculations retain input IDs and formula. For model-based coding retain model identifier when available, prompt version, codebook version and human review status. Do not fabricate tool metadata unavailable from the host.

Raw and rendered facts must be separate rows or explicitly named fields. An empty raw canonical, a missing tag and a rendered canonical are three different observations. A request error is not a page fact. A selected calendar date is not an appointment confirmed by a branch.

## Cleaning and entity resolution
Keep immutable raw evidence outside the public Git tree, with content hashes and retrieval status. Normalize whitespace and encoding for comparison, retaining originals. Deduplicate exact text via hash and near-duplicates via documented similarity rules. Preserve syndicated content relationships, translations, quoted sources and common product databases in independence clusters.

Map Toyota/Auto2000/adviser/partner entities explicitly. Reconcile aliases such as model marketing names and variant codes manually on the pilot. Never merge records solely because two reviewers share a display name. Remove personal identifiers from published qualitative excerpts; keep only necessary topic/task context.

## Missingness and validation
Use explicit reasons: not_applicable, not_collected, access_blocked, parser_failed, not_present_in_sample, not_disclosed, stale_or_conflicting. Null is not zero. Preserve original string and parsed number for prices, dates and specifications. Validate ranges, currency, counts, dates and categorical values. A boolean in an airbag-count field should be flagged rather than silently coerced.

## Storage and versioning
Start with UTF-8 JSONL/CSV; move large fact/link tables to partitioned Parquet if available. Partition by source family and run date without producing thousands of tiny files. Keep code, schemas, small reviewed extracts and manifests in Git; keep bulk HTML, screenshots and large datasets in an appropriate artifact store with versioned references. The plan does not require buying storage. If existing resources cannot retain a proposed corpus, reduce collection before starting.

Each final analysis gets a frozen evidence cutoff and dependency list. Revisions update affected claims and outputs, not just the chart. The public ZIP must be reproducible from its documented inputs but should not expose private uploads or redistribute entire third-party sites.
