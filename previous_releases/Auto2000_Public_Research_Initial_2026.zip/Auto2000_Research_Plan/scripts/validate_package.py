#!/usr/bin/env python3
"""Offline structural check only; never makes network requests."""
from pathlib import Path
import json,csv,hashlib,re
root=Path(__file__).resolve().parents[1]
errors=[]
for p in root.rglob('*.json'):
    try: json.loads(p.read_text())
    except Exception as e: errors.append(f'{p}: {e}')
for p in (root/'templates').glob('*.csv'):
    rows=list(csv.reader(p.open(newline='')))
    if not rows or len(rows[0])!=len(set(rows[0])): errors.append(f'Invalid CSV header: {p}')
cfg=json.loads((root/'config/run_plan.json').read_text())
if cfg['execution_enabled'] or cfg['broad_run_authorized']: errors.append('Planning-only execution guard changed')
for p in root.rglob('*.md'):
    for link in re.findall(r'`((?:docs|config|schemas|scripts|templates)/[^`]+)`',p.read_text()):
        if not (root/link).exists(): errors.append(f'Missing local target: {link}')
manifest=root/'manifests/files.json'
if manifest.exists():
    for item in json.loads(manifest.read_text())['files']:
        p=root/item['path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']: errors.append(f'Hash mismatch: {p}')
if errors: raise SystemExit('FAIL\n'+'\n'.join(errors))
print('PASS: JSON, CSV headers, local document paths, planning guards and manifest hashes. No network activity.')
