#!/usr/bin/env python3
"""Build a ZIP of this reviewed planning tree, without network activity."""
from pathlib import Path
import zipfile
root=Path(__file__).resolve().parents[1]
out=root.parent/(root.name+'.zip')
forbidden={'.git','.venv','node_modules','__pycache__','raw','cache','browser_profiles'}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file() and not (set(p.relative_to(root).parts)&forbidden) and not p.name.startswith('.env'):
            z.write(p,Path(root.name)/p.relative_to(root))
print(out)
