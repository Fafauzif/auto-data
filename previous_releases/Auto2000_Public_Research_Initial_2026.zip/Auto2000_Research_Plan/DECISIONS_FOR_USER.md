# Decisions before the later run

Already settled: broad discovery plus IBSC relevance; existing accessible resources only; public sources; no new accounts or paid tools; no large run yet. The supplied mentoring notes and BCC Hub define insight quality and evidence discipline.

Please resolve these before launch:

1. **First execution scope:** start with the bounded pilot in this plan, or authorize a larger named stage? Recommendation: pilot first, return the inventory/quality report, then size the large run using measured yield.
2. **Time budget:** how many hours may the later active run use? This is a ceiling, subject to what the host actually supports. Recommendation: specify a bounded first session with resumable checkpoints rather than assume a guaranteed overnight process.
3. **Release audience:** will your GitHub repository be public, private or undecided? Default: package as public-safe, excluding source uploads and raw copyrighted material. Private storage is not automatic permission to collect private data.
4. **Comparison emphasis:** should the broad benchmark prioritize Indonesian dealer competitors, EV OEM journeys, or both? Default: both in separate matched-job cohorts; keep all 4S tasks and a dedicated EV layer.
5. **Later output depth:** do you want the full evidence project plus a long report, or also an IBSC-ready argument/appendix pack? Default: research project plus report and an IBSC bridge, with actual case recommendations only after synthesis.

None of these questions block finishing the planning ZIP. They block choosing and launching an appropriately bounded later run. No additional files or accounts are required to review this plan.
