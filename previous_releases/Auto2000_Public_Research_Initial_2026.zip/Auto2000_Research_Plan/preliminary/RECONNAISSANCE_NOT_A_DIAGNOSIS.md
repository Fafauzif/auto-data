# Earlier exploratory sample: keep separate from the planned study

Observed 10 November 2026. This was started before the user clarified planning-only scope and was stopped. It is not a completed audit, balanced sample, user study, mobile test or large run.

## Browser observations
The public homepage and title identify Auto2000 Digiroom. Website/app equivalence is not established. The homepage exposes shopping, ownership/service, promotions, local branches and app-download routes. Product pages provide variant/colour selection, price, brochure, credit simulation, comparison and test-drive entry points. Multiple lead forms and contact prompts were present. A credit simulation returned estimates without requiring contact details; monthly income was optional and left empty.

An Innova hybrid versus conventional variant comparison populated after model/type selection. The hybrid starting price was Rp475.4 million and conventional Rp437.7 million in the observed location context. “Jumlah Airbag” displayed TRUE rather than a count, and several fields were unavailable. These are data-presentation review leads, not evidence of lost sales.

Catalogue filtering exposed fuel labels Bensin, Diesel, EV and HYBRID. The visible maximum price slider showed Rp105,369,999,981,654, an implausible consumer-car filter ceiling. The catalogue's long informational text included bZ4X values above Rp1.2 billion while its current product card showed Rp799 million. Model/year/variant and content freshness must be reconciled before classifying the difference.

Service booking required adding model/year/type/plate before the next service/branch options could be explored. No customer or vehicle identity was entered. bZ4X test drive allowed branch selection and showed a calendar stating dates from two to fourteen days ahead. No appointment or lead was submitted, no fulfillment was tested. Trade-in data requirements were inspected without producing an estimate.

Two benchmark pages were inspected: BYD's public test-drive page and Toyota's electrification education site. This was enough to discover potential comparison criteria, not enough to rank competitors. Toyota's site already exposes HEV/PHEV/BEV education and a health-check route, so “build EV education from scratch” is not an established gap.

## Technical sample
Eight raw HTML pages, robots, sitemap index and three child sitemaps were retained privately in scratch. The index declared 27 children; only three were examined. All three sampled children included a header-like entry with loc=URL, lastmod=Last Modified and priority=Priority. Catalogue canonical was empty in raw HTML; other raw/rendered and schema consistency leads were documented. None establishes a current Google indexing failure or revenue loss.

## Search/content sample
Five editorial/local pages were inspected through public retrieval. Leads included a cost guide without numeric budgeting examples, matching content across two adviser pages, and branch identity/capability presentation ambiguities. Search retrieval can lag the live site. Existing EV educational content was found; completeness and usefulness remain research questions.

## Measurement failures
Four public PSI attempts (two pages × two devices) returned daily quota-exceeded responses. No Lighthouse or Core Web Vitals score was obtained. Some raw HTTP requests returned 403 while other retrieval surfaces succeeded. No cause was established. These are access/measurement limits, not proof that ordinary visitors face the same failures.

## How to use these leads
Use them to test extraction instruments and select rival explanations. Recheck independently in the balanced pilot; do not let this issue-seeking sample determine prevalence, priority or final diagnosis. No mobile UX, traffic, rankings, conversion or user-demographic claim is supported by this reconnaissance.
