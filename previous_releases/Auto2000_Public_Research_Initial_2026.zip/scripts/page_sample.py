import csv,subprocess,time,json,datetime,urllib.parse
from html.parser import HTMLParser
from pathlib import Path
root=Path(__file__).resolve().parents[1]; out=root/'results'; seen=set(); sample=[]
with (out/'sitemap_urls.csv').open(encoding='utf8',newline='') as f:
 for row in csv.DictReader(f):
  family=row['source_sitemap']; p=urllib.parse.urlsplit(row['declared_url'])
  if family not in seen and not p.query and not any(p.path.startswith(x) for x in ('/login','/cart','/checkout','/my-account','/page','/tag','/category','/api/')):
   sample.append(row);seen.add(family)
class Reader(HTMLParser):
 def __init__(self): super().__init__();self.meta={};self.title='';self.in_title=False;self.h1=[];self.in_h1=False
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if tag=='title': self.in_title=True
  if tag=='h1': self.in_h1=True
  if tag=='meta' and d.get('name','').lower() in ('description','robots'): self.meta[d['name'].lower()]=d.get('content','')
  if tag=='link' and 'canonical' in d.get('rel','').lower().split():self.meta['canonical']=d.get('href','')
 def handle_endtag(self,tag):
  if tag=='title': self.in_title=False
  if tag=='h1': self.in_h1=False
 def handle_data(self,data):
  if self.in_title:self.title+=data
  if self.in_h1:self.h1.append(data)
records=[]
for row in sample[:20]:
 url=row['declared_url'];p=subprocess.run(['curl','-fsSL','--max-time','25','--max-filesize','3000000',url],capture_output=True)
 record={'url':url,'source_sitemap':row['source_sitemap'],'return_code':p.returncode,'bytes':len(p.stdout),'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 if p.returncode==0:
  reader=Reader();reader.feed(p.stdout.decode('utf8',errors='replace'));record.update(title=reader.title.strip(),h1=' '.join(' '.join(reader.h1).split()),**reader.meta)
 records.append(record)
 (out/'page_sample.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
 print(len(records),record['return_code'],url,flush=True)
 if p.returncode:break
 time.sleep(1)
