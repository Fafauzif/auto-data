import csv,xml.etree.ElementTree as ET,subprocess,time,datetime,json,sys
from urllib.parse import urlparse
from pathlib import Path
root=Path(__file__).resolve().parents[1]; ns={'s':'http://www.sitemaps.org/schemas/sitemap/0.9'}
index=ET.parse('/tmp/auto_sitemap'); urls=[x.text for x in index.findall('.//s:loc',ns)]; out=root/'results'; rows=[]; logs=[]
for i,url in enumerate(urls):
 p=subprocess.run(['curl','-fsSL','--max-time','30',url],capture_output=True)
 log={'sitemap':url,'return_code':p.returncode,'bytes':len(p.stdout)}
 if p.returncode==0:
  try:
   tree=ET.fromstring(p.stdout)
   for item in tree.findall('.//s:url',ns):
    loc=item.findtext('s:loc',default='',namespaces=ns); last=item.findtext('s:lastmod',default='',namespaces=ns)
    if urlparse(loc).scheme in ('https','http') and urlparse(loc).netloc=='auto2000.co.id': rows.append([url,loc,last])
   log['valid_urls']=len([x for x in rows if x[0]==url])
  except ET.ParseError as e: log['parse_error']=str(e)
 logs.append(log)
 with (out/'sitemap_urls.csv').open('w',encoding='utf8',newline='') as f:
  w=csv.writer(f);w.writerow(['source_sitemap','declared_url','lastmod']);w.writerows(rows)
 (out/'sitemap_run.json').write_text(json.dumps({'retrieved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sitemaps':logs,'url_records':len(rows),'unique_urls':len(set(x[1] for x in rows))},indent=2))
 print(i+1,len(urls),url,log,flush=True)
 if p.returncode!=0: print('Stopping due to access or retrieval failure',flush=True);break
 time.sleep(1)
